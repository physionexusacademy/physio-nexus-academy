import type { Metadata } from "next";
import { CalendarDays, MapPin, Users } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { createPublicClient } from "@/lib/supabase/public";

export const metadata: Metadata = {
  title: "Physiotherapy Workshops in Pakistan",
  description:
    "Explore hands-on physiotherapy workshops from Physio Nexus Academy, including clinical skills training in Karachi, Hyderabad and other cities in Pakistan.",
  keywords: ["physiotherapy workshops Pakistan", "manual therapy workshops", "physiotherapy training Karachi", "physiotherapy workshops Hyderabad", "clinical skills workshops"],
  openGraph: {
    title: "Physiotherapy Workshops in Pakistan | Physio Nexus Academy",
    description: "Explore practical physiotherapy workshops and clinical skills training in Karachi, Hyderabad and other Pakistani cities.",
    url: "https://physionexusacademy.com/workshops",
    siteName: "Physio Nexus Academy",
    type: "website",
  },
  alternates: {
    canonical: "https://physionexusacademy.com/workshops",
  },
};

export const dynamic = "force-static";
export const revalidate = 300; // refresh public workshop data at most every 5 minutes

export default async function WorkshopsPage() {
  const supabase = createPublicClient();
  const todayInPakistan = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Karachi", year: "numeric", month: "2-digit", day: "2-digit",
  }).format(new Date());
  const { data: workshops } = await supabase
    .from("workshops")
    .select("id,slug,title,summary,start_date,city,seat_limit,topics,is_past")
    .eq("status", "published")
    .order("start_date", { ascending: true, nullsFirst: false });

  return (
    <div className="container-content section-padding">
      <p className="text-sm font-semibold uppercase tracking-wide text-teal-600">
        Workshops
      </p>
      <h1 className="mt-2 text-3xl font-bold sm:text-4xl">
        Clinical Skill Workshops
      </h1>
      <p className="mt-4 max-w-2xl text-navy-600">
        Hands-on physiotherapy workshops connecting theory with real clinical
        application in Karachi, Hyderabad and other cities where PNA schedules training.
      </p>
      <p className="mt-3 text-sm text-navy-500">
        Browse location information for{" "}
        <a href="/locations/karachi" className="font-semibold text-teal-600 hover:underline">
          Karachi
        </a>{" "}
        and{" "}
        <a href="/locations/hyderabad" className="font-semibold text-teal-600 hover:underline">
          Hyderabad
        </a>
        .
      </p>

      {!workshops?.length && (
        <p className="mt-10 rounded-xl border border-grey-200 bg-grey-50 p-8 text-center text-navy-400">
          No workshops are published yet — check back soon, or follow our{" "}
          <a href="/updates" className="text-teal-600 hover:underline">
            updates page
          </a>{" "}
          for announcements.
        </p>
      )}

      <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {workshops?.map((w) => (
          <div
            key={w.id}
            className="flex flex-col rounded-xl border border-grey-200 p-6"
          >
            <span className="inline-block w-fit rounded-full bg-teal-50 px-3 py-1 text-xs font-semibold text-teal-700">
              {w.is_past || (w.start_date && String(w.start_date).slice(0, 10) < todayInPakistan) ? "Past" : "Upcoming"}
            </span>
            <h2 className="mt-4 font-heading text-lg font-semibold text-navy-800">
              {w.title}
            </h2>
            {w.summary && (
              <p className="mt-2 text-sm text-navy-500">{w.summary}</p>
            )}
            <div className="mt-3 space-y-1.5 text-sm text-navy-500">
              <p className="flex items-center gap-2">
                <CalendarDays className="h-4 w-4 text-teal-500" />
                {w.start_date
                  ? new Date(w.start_date).toLocaleDateString()
                  : "Date to be announced"}
              </p>
              <p className="flex items-center gap-2">
                <MapPin className="h-4 w-4 text-teal-500" />{" "}
                {w.city || "City to be announced"}
              </p>
              <p className="flex items-center gap-2">
                <Users className="h-4 w-4 text-teal-500" />
                {w.seat_limit
                  ? `${w.seat_limit} seats`
                  : "Seats to be announced"}
              </p>
            </div>
            {!!w.topics?.length && (
              <div className="mt-3 flex flex-wrap gap-1.5">
                {w.topics.map((t: string) => (
                  <span
                    key={t}
                    className="rounded-full bg-grey-100 px-2.5 py-1 text-xs text-navy-600"
                  >
                    {t}
                  </span>
                ))}
              </div>
            )}
            <Button
              href={`/workshops/${w.slug}`}
              variant="outline"
              className="mt-5"
            >
              View details &amp; register
            </Button>
          </div>
        ))}
      </div>

      <section className="mt-14 rounded-2xl border border-grey-200 bg-grey-50 p-6 sm:p-8">
        <p className="text-xs font-semibold uppercase tracking-wider text-teal-600">
          Professional Portfolio
        </p>
        <h2 className="mt-2 text-2xl font-bold text-navy-800">
          Past Workshops &amp; Clinical Training
        </h2>
        <p className="mt-3 max-w-2xl text-sm leading-6 text-navy-600">
          Explore documented workshops, internship programs and clinical training
          activities from the professional portfolio of Physio Nexus Academy and
          Dr. Sajjad Raza PT.
        </p>
        <Button href="/training" variant="outline" className="mt-5">
          View Training Archive
        </Button>
      </section>
    </div>
  );
}
