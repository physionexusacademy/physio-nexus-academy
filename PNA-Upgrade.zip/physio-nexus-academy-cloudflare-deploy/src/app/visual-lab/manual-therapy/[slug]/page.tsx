import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, ArrowRight, Images, ShieldCheck } from "lucide-react";
import {
  completeRegionalManualApplications,
  getRegionalManualApplication,
} from "@/lib/manual-therapy-regional";
import { getManualTherapyVisualSpec } from "@/lib/manual-therapy-visual-specs";
import TechniqueRealVisual from "@/components/manual-therapy/TechniqueRealVisual";

type PageProps = {
  params: Promise<{ slug: string }>;
};

export function generateStaticParams() {
  return completeRegionalManualApplications
    .filter((item) => !item.slug.endsWith("-") && item.slug !== "guide-")
    .map((item) => ({ slug: item.slug }));
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { slug } = await params;
  const item = getRegionalManualApplication(slug);
  if (!item) return {};

  return {
    title: item.title + " Visuals | PNA Visual Lab",
    description:
      "Technique-specific clinical visuals for " + item.title + " in the PNA Visual Lab.",
  };
}

export default async function ManualTherapyVisualDetailPage({ params }: PageProps) {
  const { slug } = await params;
  const item = getRegionalManualApplication(slug);
  if (!item) notFound();

  const visual = getManualTherapyVisualSpec(item.slug);

  return (
    <div className="container-content section-padding pb-28">
      <Link
        href="/visual-lab/manual-therapy"
        className="inline-flex items-center gap-2 text-sm font-bold text-violet-700"
      >
        <ArrowLeft className="h-4 w-4" />
        Manual Therapy Visual Lab
      </Link>

      <section className="mt-5 overflow-hidden rounded-[2rem] bg-gradient-to-br from-violet-800 via-indigo-900 to-slate-950 p-7 text-white shadow-xl sm:p-10">
        <div className="flex flex-wrap gap-2">
          <span className="rounded-full border border-white/15 bg-white/10 px-3 py-1 text-xs font-bold">
            {item.region}
          </span>
          <span className="rounded-full border border-white/15 bg-white/10 px-3 py-1 text-xs font-bold">
            {item.techniqueName}
          </span>
        </div>
        <p className="mt-5 text-xs font-bold uppercase tracking-[0.22em] text-cyan-200">
          PNA Technique Visuals
        </p>
        <h1 className="mt-2 text-3xl font-bold leading-tight sm:text-5xl">{item.title}</h1>
        <p className="mt-4 max-w-3xl text-sm leading-7 text-indigo-100">
          This page is reserved for the technique’s real textbook-style clinical visuals.
          The original technique theory remains on the clinical guide page.
        </p>
      </section>

      {visual ? (
        <section className="mt-8">
          <div className="flex items-center gap-3">
            <ShieldCheck className="h-6 w-6 text-emerald-700" />
            <div>
              <p className="text-xs font-bold uppercase tracking-[0.18em] text-emerald-700">
                Technique-specific visual
              </p>
              <h2 className="text-2xl font-bold text-navy-900">
                Real anatomy + exact target + force direction
              </h2>
            </div>
          </div>

          <div className="mt-5">
            <TechniqueRealVisual spec={visual} eager />
          </div>
        </section>
      ) : (
        <section className="mt-8 rounded-3xl border border-violet-100 bg-white p-6 shadow-sm sm:p-8">
          <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-violet-50 text-violet-700">
            <Images className="h-6 w-6" />
          </span>
          <h2 className="mt-4 text-2xl font-bold text-navy-900">Visual set is in clinical QC</h2>
          <p className="mt-2 max-w-2xl text-sm leading-7 text-navy-600">
            No old atlas image or generic placeholder is shown here. This page stays empty until a technique-specific real visual is ready.
          </p>
        </section>
      )}

      <div className="mt-8 flex flex-wrap gap-3">
        <Link
          href={"/manual-therapy/regions/" + item.slug}
          className="inline-flex items-center gap-2 rounded-xl bg-violet-700 px-5 py-3 text-sm font-bold text-white shadow-sm"
        >
          Back to technique theory
          <ArrowRight className="h-4 w-4" />
        </Link>
        <Link
          href="/visual-lab/manual-therapy"
          className="rounded-xl border border-grey-200 bg-white px-5 py-3 text-sm font-bold text-navy-700 shadow-sm"
        >
          Browse all technique visuals
        </Link>
      </div>
    </div>
  );
}
