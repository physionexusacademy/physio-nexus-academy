/**
 * Central reference library for the MSK conditions, treatment plans and special tests.
 *
 * VERIFICATION POLICY
 * Every citation below was written from the author's working knowledge while OFFLINE.
 * None has been opened on PubMed, a publisher site or a DOI resolver during authoring.
 * Each entry therefore carries verification: "unverified" and the website shows an
 * "Unverified - check source" badge. Change an entry to "verified" ONLY after a person has
 * opened the DOI/PubMed record and confirmed authors, title, journal, year and the claim it supports.
 */

export type EvidenceKind =
  | "Clinical practice guideline"
  | "Systematic review"
  | "Randomized trial"
  | "Diagnostic accuracy study"
  | "Prediction / cohort study"
  | "Consensus statement"
  | "Narrative review";

export type RefVerification = "unverified" | "verified";

export type EvidenceRef = {
  citation: string;
  kind: EvidenceKind;
  doi?: string;
  url?: string;
  verification: RefVerification;
};

const r = (
  kind: EvidenceKind,
  citation: string,
  doi?: string,
  url?: string,
): EvidenceRef => ({ kind, citation, ...(doi ? { doi } : {}), ...(url ? { url } : {}), verification: "unverified" });

export const EVIDENCE_REFS = {
  // ---- Neck / cervical ----
  wainner2003: r("Diagnostic accuracy study", "Wainner RS, Fritz JM, Irrgang JJ, Boninger ML, Delitto A, Allison S. Reliability and diagnostic accuracy of the clinical examination and patient self-report measures for cervical radiculopathy. Spine. 2003;28(1):52-62.", "10.1097/00007632-200301010-00014"),
  rubinstein2007: r("Systematic review", "Rubinstein SM, Pool JJM, van Tulder MW, Riphagen II, de Vet HCW. A systematic review of the diagnostic accuracy of provocative tests of the neck for diagnosing cervical radiculopathy. Eur Spine J. 2007;16(3):307-319.", "10.1007/s00586-006-0225-6"),
  blanpied2017: r("Clinical practice guideline", "Blanpied PR, Gross AR, Elliott JM, et al. Neck pain: revision 2017. J Orthop Sports Phys Ther. 2017;47(7):A1-A83.", "10.2519/jospt.2017.0302"),
  gross2015manip: r("Systematic review", "Gross A, Langevin P, Burnie SJ, et al. Manipulation and mobilisation for neck pain contrasted against an inactive control or another active treatment. Cochrane Database Syst Rev. 2015;(9):CD004249.", "10.1002/14651858.CD004249.pub4"),
  gross2015ex: r("Systematic review", "Gross A, Kay TM, Paquin JP, et al. Exercises for mechanical neck disorders. Cochrane Database Syst Rev. 2015;(1):CD004250.", "10.1002/14651858.CD004250.pub5"),
  thoomes2013: r("Systematic review", "Thoomes EJ, Scholten-Peeters W, Koes B, Falla D, Verhagen AP. The effectiveness of conservative treatment for patients with cervical radiculopathy: a systematic review. Clin J Pain. 2013;29(12):1073-1086."),
  cook2010myelopathy: r("Prediction / cohort study", "Cook C, Brown C, Isaacs R, Roman M, Davis S, Richardson W. Clustering of clinical findings to identify cervical myelopathy. J Man Manip Ther. 2010;18(4):175-180."),
  ogince2007: r("Diagnostic accuracy study", "Ogince M, Hall T, Robinson K, Blackmore AM. The diagnostic validity of the cervical flexion-rotation test in C1/2-related cervicogenic headache. Man Ther. 2007;12(3):256-262."),
  jull2008: r("Narrative review", "Jull GA, O'Leary SP, Falla DL. Clinical assessment of the deep cervical flexor muscles: the craniocervical flexion test. J Manipulative Physiol Ther. 2008;31(7):525-533.", "10.1016/j.jmpt.2008.08.003"),
  ifompt2023: r("Consensus statement", "Rushton A, Carlesso LC, Flynn T, et al. International Framework for Examination of the Cervical Region for potential of vascular pathologies of the neck prior to musculoskeletal intervention: International IFOMPT Cervical Framework. J Orthop Sports Phys Ther. 2023;53(1):7-22."),

  // ---- Lumbar / pelvis ----
  george2021: r("Clinical practice guideline", "George SZ, Fritz JM, Silfies SP, et al. Interventions for the management of acute and chronic low back pain: revision 2021. J Orthop Sports Phys Ther. 2021;51(11):CPG1-CPG60.", "10.2519/jospt.2021.0304"),
  niceNG59: r("Clinical practice guideline", "National Institute for Health and Care Excellence. Low back pain and sciatica in over 16s: assessment and management (NG59). London: NICE; 2016 (updated 2020).", undefined, "https://www.nice.org.uk/guidance/ng59"),
  vanderwindt2010: r("Systematic review", "van der Windt DAWM, Simons E, Riphagen II, et al. Physical examination for lumbar radiculopathy due to disc herniation in patients with low-back pain. Cochrane Database Syst Rev. 2010;(2):CD007431.", "10.1002/14651858.CD007431.pub2"),
  majlesi2008: r("Diagnostic accuracy study", "Majlesi J, Togay H, Unalan H, Toprak S. The sensitivity and specificity of the Slump and the Straight Leg Raising tests in patients with lumbar disc herniation. J Clin Rheumatol. 2008;14(2):87-91."),
  lewis2015: r("Systematic review", "Lewis RA, Williams NH, Sutton AJ, et al. Comparative clinical effectiveness of management strategies for sciatica: systematic review and network meta-analyses. Spine J. 2015;15(6):1461-1477.", "10.1016/j.spinee.2013.08.049"),
  laslett2005: r("Diagnostic accuracy study", "Laslett M, Aprill CN, McDonald B, Young SB. Diagnosis of sacroiliac joint pain: validity of individual provocation tests and composites of tests. Man Ther. 2005;10(3):207-218.", "10.1016/j.math.2005.01.003"),
  mens2001: r("Diagnostic accuracy study", "Mens JMA, Vleeming A, Snijders CJ, Koes BW, Stam HJ. Reliability and validity of the active straight leg raise test in posterior pelvic pain since pregnancy. Spine. 2001;26(10):1167-1171."),
  french2006: r("Systematic review", "French SD, Cameron M, Walker BF, Reggars JW, Esterman AJ. Superficial heat or cold for low back pain. Cochrane Database Syst Rev. 2006;(1):CD004750.", "10.1002/14651858.CD004750.pub2"),
  ebadi2014: r("Systematic review", "Ebadi S, Henschke N, Nakhostin Ansari N, Fallah-Mohammadi Z, van Tulder MW. Therapeutic ultrasound for chronic low-back pain. Cochrane Database Syst Rev. 2014;(3):CD009169.", "10.1002/14651858.CD009169.pub2"),

  // ---- Shoulder ----
  hegedus2012: r("Systematic review", "Hegedus EJ, Goode AP, Cook CE, et al. Which physical examination tests provide clinicians with the most value when examining the shoulder? Update of a systematic review with meta-analysis of individual tests. Br J Sports Med. 2012;46(14):964-978.", "10.1136/bjsports-2012-091066"),
  hermans2013: r("Systematic review", "Hermans J, Luime JJ, Meuffels DE, Reijman M, Simel DL, Bierma-Zeinstra SMA. Does this patient with shoulder pain have rotator cuff disease? The Rational Clinical Examination systematic review. JAMA. 2013;310(8):837-847.", "10.1001/jama.2013.276187"),
  park2005: r("Diagnostic accuracy study", "Park HB, Yokota A, Gill HS, El Rassi G, McFarland EG. Diagnostic accuracy of clinical tests for the different degrees of subacromial impingement syndrome. J Bone Joint Surg Am. 2005;87(7):1446-1455.", "10.2106/JBJS.D.02335"),
  barth2006: r("Diagnostic accuracy study", "Barth JRH, Burkhart SS, De Beer JF. The bear-hug test: a new and sensitive test for diagnosing a subscapularis tear. Arthroscopy. 2006;22(10):1076-1084."),
  kuhn2013: r("Prediction / cohort study", "Kuhn JE, Dunn WR, Sanders R, et al. Effectiveness of physical therapy in treating atraumatic full-thickness rotator cuff tears: a multicenter prospective cohort study. J Shoulder Elbow Surg. 2013;22(10):1371-1379.", "10.1016/j.jse.2013.01.026"),
  kelley2013: r("Clinical practice guideline", "Kelley MJ, Shaffer MA, Kuhn JE, et al. Shoulder pain and mobility deficits: adhesive capsulitis. J Orthop Sports Phys Ther. 2013;43(5):A1-A31.", "10.2519/jospt.2013.0302"),
  rangan2020: r("Randomized trial", "Rangan A, Brealey SD, Keding A, et al. Management of adults with primary frozen shoulder in secondary care (UK FROST): a multicentre, pragmatic, three-arm, superiority randomised clinical trial. Lancet. 2020;396(10256):977-989.", "10.1016/S0140-6736(20)31965-6"),
  page2014: r("Systematic review", "Page MJ, Green S, Kramer S, et al. Manual therapy and exercise for adhesive capsulitis (frozen shoulder). Cochrane Database Syst Rev. 2014;(8):CD011275.", "10.1002/14651858.CD011275"),

  // ---- Elbow / wrist / hand ----
  coombes2009: r("Narrative review", "Coombes BK, Bisset L, Vicenzino B. A new integrative model of lateral epicondylalgia. Br J Sports Med. 2009;43(4):252-258.", "10.1136/bjsm.2008.052738"),
  bisset2015: r("Narrative review", "Bisset LM, Vicenzino B. Physiotherapy management of lateral epicondylalgia. J Physiother. 2015;61(4):174-181.", "10.1016/j.jphys.2015.07.015"),
  macdermid2004: r("Systematic review", "MacDermid JC, Wessel J. Clinical diagnosis of carpal tunnel syndrome: a systematic review. J Hand Ther. 2004;17(2):309-319.", "10.1197/j.jht.2004.02.015"),
  erickson2019: r("Clinical practice guideline", "Erickson M, Lawrence M, Jansen CWS, Coker D, Amadio P, Cleary C. Hand pain and sensory deficits: carpal tunnel syndrome. J Orthop Sports Phys Ther. 2019;49(5):CPG1-CPG85.", "10.2519/jospt.2019.0301"),
  ilyas2007: r("Narrative review", "Ilyas AM, Ast M, Schaffer AA, Thoder J. De Quervain tenosynovitis of the wrist. J Am Acad Orthop Surg. 2007;15(12):757-764."),

  // ---- Hip / groin ----
  reiman2015: r("Systematic review", "Reiman MP, Goode AP, Cook CE, Holmich P, Thorborg K. Diagnostic accuracy of clinical tests for the diagnosis of hip femoroacetabular impingement/labral tear: a systematic review with meta-analysis. Br J Sports Med. 2015;49(12):811.", "10.1136/bjsports-2014-094302"),
  griffin2016: r("Consensus statement", "Griffin DR, Dickenson EJ, O'Donnell J, et al. The Warwick Agreement on femoroacetabular impingement syndrome (FAI syndrome): an international consensus statement. Br J Sports Med. 2016;50(19):1169-1176.", "10.1136/bjsports-2016-096743"),
  sutlive2008: r("Prediction / cohort study", "Sutlive TG, Lopez HP, Schnitker DE, et al. Development of a clinical prediction rule for diagnosing hip osteoarthritis in individuals with unilateral hip pain. J Orthop Sports Phys Ther. 2008;38(9):542-550."),
  weir2015: r("Consensus statement", "Weir A, Brukner P, Delahunt E, et al. Doha agreement meeting on terminology and definitions in groin pain in athletes. Br J Sports Med. 2015;49(12):768-774."),
  holmich2004: r("Diagnostic accuracy study", "Holmich P, Holmich LR, Bjerg AM. Clinical examination of athletes with groin pain: an intraobserver and interobserver reliability study. Br J Sports Med. 2004;38(4):446-451."),
  maslowski2010: r("Diagnostic accuracy study", "Maslowski E, Sullivan W, Forster Harwood J, et al. The diagnostic validity of hip provocation maneuvers to detect intra-articular hip pathology. PM R. 2010;2(3):174-181."),
  mellor2018: r("Randomized trial", "Mellor R, Bennell K, Grimaldi A, et al. Education plus exercise versus corticosteroid injection use versus a wait and see approach on global outcome and pain from gluteal tendinopathy: prospective, single blinded, randomised clinical trial. BMJ. 2018;361:k1662.", "10.1136/bmj.k1662"),
  grimaldi2015: r("Narrative review", "Grimaldi A, Mellor R, Hodges P, Bennell K, Wajswelner H, Vicenzino B. Gluteal tendinopathy: a review of mechanisms, assessment and management. Sports Med. 2015;45(8):1107-1119."),
  lequesne2008: r("Diagnostic accuracy study", "Lequesne M, Mathieu P, Vuillemin-Bodaghi V, Bard H, Djian P. Gluteal tendinopathy in refractory greater trochanter pain syndrome: diagnostic value of two clinical tests. Arthritis Rheum. 2008;59(2):241-246."),

  // ---- Knee ----
  benjaminse2006: r("Systematic review", "Benjaminse A, Gokeler A, van der Schans CP. Clinical diagnosis of an anterior cruciate ligament rupture: a meta-analysis. J Orthop Sports Phys Ther. 2006;36(5):267-288.", "10.2519/jospt.2006.2011"),
  hegedus2007: r("Systematic review", "Hegedus EJ, Cook C, Hasselblad V, Goode A, McCrory DC. Physical examination tests for assessing a torn meniscus in the knee: a systematic review with meta-analysis. J Orthop Sports Phys Ther. 2007;37(9):541-550.", "10.2519/jospt.2007.2560"),
  karachalios2005: r("Diagnostic accuracy study", "Karachalios T, Hantes M, Zibis AH, et al. Diagnostic accuracy of a new clinical test (the Thessaly test) for early detection of meniscal tears. J Bone Joint Surg Am. 2005;87(5):955-962."),
  daniel1988: r("Diagnostic accuracy study", "Daniel DM, Stone ML, Barnett P, Sachs R. Use of the quadriceps active test to diagnose posterior cruciate-ligament disruption and measure posterior laxity of the knee. J Bone Joint Surg Am. 1988;70(3):386-391."),
  willy2019: r("Clinical practice guideline", "Willy RW, Hoglund LT, Barton CJ, et al. Patellofemoral pain: clinical practice guidelines linked to the International Classification of Functioning, Disability and Health. J Orthop Sports Phys Ther. 2019;49(9):CPG1-CPG95.", "10.2519/jospt.2019.0302"),
  fransen2015: r("Systematic review", "Fransen M, McConnell S, Harmer AR, Van der Esch M, Simic M, Bennell KL. Exercise for osteoarthritis of the knee: a Cochrane systematic review. Br J Sports Med. 2015;49(24):1554-1557.", "10.1136/bjsports-2015-095424"),
  grindem2016: r("Prediction / cohort study", "Grindem H, Snyder-Mackler L, Moksnes H, Engebretsen L, Risberg MA. Simple decision rules can reduce reinjury risk by 84% after ACL reconstruction: the Delaware-Oslo ACL cohort study. Br J Sports Med. 2016;50(13):804-808.", "10.1136/bjsports-2016-096031"),
  kyritsis2016: r("Prediction / cohort study", "Kyritsis P, Bahr R, Landreau P, Miladi R, Witvrouw E. Likelihood of ACL graft rupture: not meeting six clinical discharge criteria before return to sport is associated with a four times greater risk of rupture. Br J Sports Med. 2016;50(15):946-951.", "10.1136/bjsports-2015-095908"),

  // ---- Ankle / foot / tendon ----
  martin2021ankle: r("Clinical practice guideline", "Martin RL, Davenport TE, Fraser JJ, et al. Ankle stability and movement coordination impairments: lateral ankle ligament sprains revision 2021. J Orthop Sports Phys Ther. 2021;51(4):CPG1-CPG80.", "10.2519/jospt.2021.0302"),
  vandijk1996: r("Diagnostic accuracy study", "van Dijk CN, Lim LS, Bossuyt PM, Marti RK. Physical examination is sufficient for the diagnosis of sprained ankles. J Bone Joint Surg Br. 1996;78(6):958-962."),
  martin2018achilles: r("Clinical practice guideline", "Martin RL, Chimenti R, Cuddeford T, et al. Achilles pain, stiffness, and muscle power deficits: midportion Achilles tendinopathy revision 2018. J Orthop Sports Phys Ther. 2018;48(5):A1-A38.", "10.2519/jospt.2018.0302"),
  beyer2015: r("Randomized trial", "Beyer R, Kongsgaard M, Hougs Kjaer B, Ohlenschlaeger T, Kjaer M, Magnusson SP. Heavy slow resistance versus eccentric training as treatment for Achilles tendinopathy: a randomized controlled trial. Am J Sports Med. 2015;43(7):1704-1711.", "10.1177/0363546515584760"),
  cook2009: r("Narrative review", "Cook JL, Purdam CR. Is tendon pathology a continuum? A pathology model to explain the clinical presentation of load-induced tendinopathy. Br J Sports Med. 2009;43(6):409-416.", "10.1136/bjsm.2008.051193"),
  maffulli1998: r("Diagnostic accuracy study", "Maffulli N. The clinical diagnosis of subcutaneous tear of the Achilles tendon: a prospective study in 174 patients. Am J Sports Med. 1998;26(2):266-270."),
  hebertlosier2009: r("Systematic review", "Hebert-Losier K, Newsham-West RJ, Schneiders AG, Sullivan SJ. Raising the standards of the calf-raise test: a systematic review. J Sci Med Sport. 2009;12(6):594-602.", "10.1016/j.jsams.2008.12.628"),
  koc2023: r("Clinical practice guideline", "Koc TA Jr, Bise CG, Neville C, Carreira D, Martin RL, McDonough CM. Heel pain - plantar fasciitis: revision 2023. J Orthop Sports Phys Ther. 2023;53(12):CPG1-CPG39."),
  degarceau2003: r("Diagnostic accuracy study", "De Garceau D, Dean D, Requejo SM, Thordarson DB. The association between diagnosis of plantar fasciitis and Windlass test results. Foot Ankle Int. 2003;24(3):251-255."),
  manibabu2015: r("Systematic review", "Mani-Babu S, Morrissey D, Waugh C, Screen H, Barton C. The effectiveness of extracorporeal shock wave therapy in lower limb tendinopathy: a systematic review. Am J Sports Med. 2015;43(3):752-761."),

  // ---- Added for test-evidence module ----
  hicks2005: r("Prediction / cohort study", "Hicks GE, Fritz JM, Delitto A, McGill SM. Preliminary development of a clinical prediction rule for determining which patients with low back pain will respond to a stabilization exercise program. Arch Phys Med Rehabil. 2005;86(9):1753-1762."),
  odriscoll2005: r("Diagnostic accuracy study", "O'Driscoll SW, Lawton RL, Smith AM. The 'moving valgus stress test' for medial collateral ligament tears of the elbow. Am J Sports Med. 2005;33(2):231-239."),
  novak1994: r("Diagnostic accuracy study", "Novak CB, Lee GW, Mackinnon SE, Lay L. Provocative testing for cubital tunnel syndrome. J Hand Surg Am. 1994;19(5):817-820."),
  goubau2014: r("Diagnostic accuracy study", "Goubau JF, Goubau L, Van Tongel A, Van Hoonacker P, Kerckhove D, Berghs B. The wrist hyperflexion and abduction of the thumb (WHAT) test: a more specific and sensitive test to diagnose de Quervain tenosynovitis than the Eichhoff's test. J Hand Surg Eur Vol. 2014;39(3):286-292."),
  tay2007: r("Diagnostic accuracy study", "Tay SC, Tomita K, Berger RA. The 'ulnar fovea sign' for defining ulnar wrist pain: an analysis of sensitivity and specificity. J Hand Surg Am. 2007;32(4):438-444."),
  martin2008: r("Diagnostic accuracy study", "Martin RL, Irrgang JJ, Sekiya JK. The diagnostic accuracy of a clinical examination in determining intra-articular hip pain for potential hip arthroscopy candidates. Arthroscopy. 2008;24(9):1013-1018."),
  willett2016: r("Narrative review", "Willett GM, Keim SA, Shostrom VK, Lomneth CS. An anatomic investigation of the Ober test. Am J Sports Med. 2016;44(3):696-701."),
  rubinstein1994: r("Diagnostic accuracy study", "Rubinstein RA Jr, Shelbourne KD, McCarroll JR, VanMeter CD, Rettig AC. The accuracy of the clinical examination in the setting of posterior cruciate ligament injuries. Am J Sports Med. 1994;22(4):550-557."),
  sman2015: r("Diagnostic accuracy study", "Sman AD, Hiller CE, Rae K, et al. Diagnostic accuracy of clinical tests for ankle syndesmosis injury. Br J Sports Med. 2015;49(5):323-329."),

  askling2013: r("Randomized trial", "Askling CM, Tengvar M, Thorstensson A. Acute hamstring injuries in Swedish elite football: a prospective randomised controlled clinical trial comparing two rehabilitation protocols. Br J Sports Med. 2013;47(15):953-959.", "10.1136/bjsports-2013-092165"),

  // ---- Tranche 2 ----
  bussieres2016: r("Clinical practice guideline", "Bussieres AE, Stewart G, Al-Zoubi F, et al. The treatment of neck pain-associated disorders and whiplash-associated disorders: a clinical practice guideline. J Manipulative Physiol Ther. 2016;39(8):523-564.e27."),
  spitzer1995: r("Consensus statement", "Spitzer WO, Skovron ML, Salmi LR, et al. Scientific monograph of the Quebec Task Force on Whiplash-Associated Disorders: redefining whiplash and its management. Spine. 1995;20(8 Suppl):1S-73S."),
  jull2002: r("Randomized trial", "Jull G, Trott P, Potter H, et al. A randomized controlled trial of exercise and manipulative therapy for cervicogenic headache. Spine. 2002;27(17):1835-1843."),
  briggs2009: r("Systematic review", "Briggs AM, Smith AJ, Straker LM, Bragge P. Thoracic spine pain in the general population: prevalence, incidence and associated factors in children, adolescents and adults. A systematic review. BMC Musculoskelet Disord. 2009;10:77."),
  kreiner2013: r("Clinical practice guideline", "Kreiner DS, Shaffer WO, Baisden JL, et al. An evidence-based clinical guideline for the diagnosis and treatment of degenerative lumbar spinal stenosis (update). Spine J. 2013;13(7):734-743."),
  zaina2016: r("Systematic review", "Zaina F, Tomkins-Lane C, Carragee E, Negrini S. Surgical versus non-surgical treatment for lumbar spinal stenosis. Cochrane Database Syst Rev. 2016;(1):CD010264.", "10.1002/14651858.CD010264.pub2"),
  malliaras2015: r("Narrative review", "Malliaras P, Cook J, Purdam C, Rio E. Patellar tendinopathy: clinical diagnosis, load management, and advice for challenging case presentations. J Orthop Sports Phys Ther. 2015;45(11):887-898."),
  kongsgaard2009: r("Randomized trial", "Kongsgaard M, Kovanen V, Aagaard P, et al. Corticosteroid injections, eccentric decline squat training and heavy slow resistance training in patellar tendinopathy. Scand J Med Sci Sports. 2009;19(6):790-802."),
  visentini1998: r("Prediction / cohort study", "Visentini PJ, Khan KM, Cook JL, Kiss ZS, Harcourt PR, Wark JD. The VISA score: an index of severity of symptoms in patients with jumper's knee (patellar tendinosis). J Sci Med Sport. 1998;1(1):22-28."),
  logerstedt2017: r("Clinical practice guideline", "Logerstedt DS, Scalzitti DA, Bennell KL, et al. Knee stability and movement coordination impairments: knee ligament sprain revision 2017. J Orthop Sports Phys Ther. 2017;47(11):A1-A47."),
  phisitkul2006: r("Narrative review", "Phisitkul P, James SL, Wolf BR, Amendola A. MCL injuries of the knee: current concepts review. Iowa Orthop J. 2006;26:77-90."),
  vleeming2008: r("Clinical practice guideline", "Vleeming A, Albert HB, Ostgaard HC, Sturesson B, Stuge B. European guidelines for the diagnosis and treatment of pelvic girdle pain. Eur Spine J. 2008;17(6):794-819.", "10.1007/s00586-008-0602-4"),
  gribble2016: r("Consensus statement", "Gribble PA, Bleakley CM, Caulfield BM, et al. Evidence review for the 2016 International Ankle Consortium consensus statement on the prevalence, impact and long-term consequences of lateral ankle sprains. Br J Sports Med. 2016;50(24):1496-1505.", "10.1136/bjsports-2016-096189"),
  hoogvliet2013: r("Systematic review", "Hoogvliet P, Randsdorp MS, Dingemanse R, Koes BW, Huisstede BM. Does effectiveness of exercise therapy and mobilisation techniques offer guidance for the treatment of lateral and medial epicondylitis? A systematic review. Br J Sports Med. 2013;47(17):1112-1119."),
  ryzewicz2006: r("Narrative review", "Ryzewicz M, Wolf JM. Trigger digits: principles, management, and complications. J Hand Surg Am. 2006;31(1):135-146."),

  // ---- Tranche 3 ----
  beitzel2014: r("Consensus statement", "Beitzel K, Mazzocca AD, Bak K, et al. ISAKOS upper extremity committee consensus statement on the need for diversification of the Rockwood classification for acromioclavicular joint injuries. Arthroscopy. 2014;30(2):271-278."),
  churgay2009: r("Narrative review", "Churgay CA. Diagnosis and treatment of biceps tendinitis and tendinosis. Am Fam Physician. 2009;80(5):470-476."),
  standaert2000: r("Narrative review", "Standaert CJ, Herring SA. Spondylolysis: a critical review. Br J Sports Med. 2000;34(6):415-422."),
  holmich1999: r("Randomized trial", "Holmich P, Uhrskou P, Ulnits L, et al. Effectiveness of active physical training as treatment for long-standing adductor-related groin pain in athletes: randomised trial. Lancet. 1999;353(9151):439-443."),

  // ---- Modalities, general ----
  bleakley2004: r("Systematic review", "Bleakley C, McDonough S, MacAuley D. The use of ice in the treatment of acute soft-tissue injury: a systematic review of randomized controlled trials. Am J Sports Med. 2004;32(1):251-261.", "10.1177/0363546503260757"),
  johnson2022: r("Systematic review", "Johnson MI, Paley CA, Jones G, Mulvey MR, Wittkopf PG. Efficacy and safety of transcutaneous electrical nerve stimulation (TENS) for acute and chronic pain in adults: a systematic review and meta-analysis of 381 studies (the meta-TENS study). BMJ Open. 2022;12(2):e051073.", "10.1136/bmjopen-2021-051073"),
} as const satisfies Record<string, EvidenceRef>;

export type RefKey = keyof typeof EVIDENCE_REFS;

export function refUrl(ref: EvidenceRef): string {
  if (ref.doi) return "https://doi.org/" + ref.doi;
  if (ref.url) return ref.url;
  // No DOI recorded: fall back to a PubMed title search so the reader can locate and verify the record.
  return "https://pubmed.ncbi.nlm.nih.gov/?term=" + encodeURIComponent(ref.citation.split(". ").slice(1, 2).join(" ") || ref.citation);
}

export function getRef(key: RefKey): EvidenceRef {
  return EVIDENCE_REFS[key];
}

export function refsFor(keys: readonly RefKey[]): (EvidenceRef & { key: RefKey; href: string })[] {
  return keys.map((key) => {
    const ref = EVIDENCE_REFS[key] as EvidenceRef;
    return { ...ref, key, href: refUrl(ref) };
  });
}

/** Adapter for the legacy { title, url } reference shape used by the condition hub. */
export function legacyRefs(keys: readonly RefKey[]): { title: string; url: string }[] {
  return keys.map((key) => {
    const ref = EVIDENCE_REFS[key] as EvidenceRef;
    return { title: ref.citation, url: refUrl(ref) };
  });
}

export const EVIDENCE_STRENGTH = ["Strong", "Moderate", "Limited", "Conflicting", "Expert consensus"] as const;
export type EvidenceStrength = (typeof EVIDENCE_STRENGTH)[number];
