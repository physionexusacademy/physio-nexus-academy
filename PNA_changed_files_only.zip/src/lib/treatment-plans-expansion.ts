import type { TreatmentPlan } from "./treatment-plans";
import type { TreatmentPlanGuide } from "./treatment-plan-guides";

/** Treatment plans added in the PNA content upgrade (merged in treatment-plans.ts / treatment-plan-guides.ts). */
export const expansionTreatmentPlans: TreatmentPlan[] = [
  {
    slug: "gluteal-tendinopathy",
    name: "Gluteal Tendinopathy (Greater Trochanteric Pain Syndrome)",
    category: "Spine & MSK",
    summary: "Education about tendon compression plus progressive hip abductor loading is the foundation. Corticosteroid injection may help short term but did not outperform education and exercise at longer follow-up in one randomised trial.",
    assessment: ["Location and behaviour of lateral hip pain (side lying, stairs, single-leg stance, crossed legs)", "Palpation of the greater trochanter and resisted abduction and external rotation", "30-second single-leg stance and Trendelenburg observation", "Hip joint range of motion and lumbar screen to exclude other sources", "Baseline function: pain on stairs, walking tolerance and night pain"],
    redFlags: ["Trauma or suspected femoral neck stress fracture", "Fever, redness or systemic illness", "Cancer history with new hip pain", "Neurological deficit in the leg", "Constant night pain unrelated to position"],
    outcomeMeasures: ["NPRS during single-leg stance and at night", "Victorian Institute of Sport Assessment for gluteal tendons (VISA-G) where available", "30-second single-leg stance time", "Patient-specific functional scale"],
    modalities: ["Corticosteroid injection (medical decision): short-term pain relief possible; long-term outcome was not better than education plus exercise in one trial", "Extracorporeal shockwave: mixed evidence, adjunct only after exercise has been tried", "Ultrasound and laser: limited evidence, not routinely recommended"],
    manualTherapy: ["Manual therapy is an adjunct only and has limited evidence", "Avoid deep compression or friction over the painful trochanter", "Hip or lumbar mobilisation only when examination implicates those regions"],
    exercises: ["Isometric hip abduction in a position that avoids tendon compression", "Progressive hip abductor and external rotator strengthening", "Sit-to-stand, step-up and single-leg loading as symptoms allow", "Graded walking and return to running"],
    homePlan: ["Avoid crossed-leg sitting, standing with the hip hanging on one side and lying on the painful side", "Use a pillow between the knees in side lying", "Perform the exercise programme 3 times per week and monitor next-day pain", "Keep walking at a comfortable level"],
    progression: ["Move from isometric to isotonic loading when pain on single-leg stance and stairs settles", "Increase load only if pain returns to baseline within 24 hours", "Add single-leg and impact tasks before returning to running"],
    escalation: ["Imaging and orthopaedic review for suspected tear with persistent weakness", "Medical review if night pain, systemic features or fracture risk emerge", "Consider injection or specialist opinion if a well-delivered programme over about 12 weeks fails"],
  },
  {
    slug: "whiplash-associated-disorder", name: "Whiplash-Associated Disorder", category: "Spine & MSK",
    summary: "Screen for fracture and neurological injury, then reassure, keep the patient active and build neck capacity. Collars and prolonged rest are avoided, and risk of persistent symptoms guides how much support is needed.",
    assessment: ["Canadian C-spine rule or equivalent before any movement testing", "Neurological and cranial nerve screen", "Active cervical range, deep neck flexor control and pain irritability", "Early pain, disability and distress as risk markers for persistence", "Dizziness, headache and driving fear"],
    redFlags: ["Fracture or instability criteria positive", "Progressive neurological deficit or myelopathic signs", "Sudden severe headache or neurological or vascular symptoms", "Worsening confusion after head injury"],
    outcomeMeasures: ["Neck Disability Index", "NPRS", "Patient-specific functional scale", "Fear-avoidance or distress screening tool"],
    modalities: ["Heat or TENS for short-term comfort only", "Soft collar not recommended for routine use", "Ultrasound not recommended as primary treatment"],
    manualTherapy: ["Mobilisation as an adjunct to exercise for short-term pain and range", "Soft-tissue work for guarding", "Avoid cervical manipulation early after trauma"],
    exercises: ["Early active neck range of motion", "Deep neck flexor retraining", "Scapular and upper-quarter strengthening", "Graded return to driving and work", "Aerobic activity"],
    homePlan: ["Stay active and avoid prolonged rest", "Do short, frequent movement sessions", "Use a graded driving plan", "Track pain and sleep and ask for review if neurology changes"],
    progression: ["Progress as pain-limited range and function improve", "Increase strength load if next-day pain settles within 24 hours", "Add graded exposure for feared activities"],
    escalation: ["Medical review for neurological or vascular signs", "Psychological or pain management referral if distress or disability persists", "Imaging per validated rules"],
  },
  {
    slug: "lumbar-spinal-stenosis", name: "Lumbar Spinal Stenosis", category: "Spine & MSK",
    summary: "Exercise, education and a graded walking programme are the first-line approach for most patients. Flexion-based positions and cycling often allow longer activity, and progressive deficit needs surgical review.",
    assessment: ["Walking tolerance and posture-dependent leg symptoms", "Neurological screen at rest and after walking", "Peripheral pulses and vascular screen", "Hip examination", "Falls risk and balance"],
    redFlags: ["Cauda equina features", "Rapidly progressive weakness", "Absent pulses or cold limbs", "Cancer, infection or night pain features"],
    outcomeMeasures: ["Swiss Spinal Stenosis Questionnaire or Oswestry Disability Index", "Walking distance or time to symptoms", "NPRS for leg and back pain", "Falls risk measures"],
    modalities: ["Heat or TENS for short-term comfort", "Traction has limited evidence and is not routinely recommended", "Ultrasound not recommended"],
    manualTherapy: ["Manual therapy with exercise may improve walking in the short term, with low-certainty evidence", "Avoid sustained extension techniques that provoke leg symptoms", "Thrust manipulation not routinely recommended"],
    exercises: ["Flexion-biased exercises and cycling", "Graded walking, including body-weight-supported options", "Hip and trunk strengthening", "Balance training"],
    homePlan: ["Use a forward-leaning posture or a walking aid when it helps", "Walk a little each day and increase gradually", "Perform strengthening 2-3 days per week"],
    progression: ["Progress walking duration when symptoms ease within agreed limits", "Add load to strengthening gradually", "Regress if leg symptoms spread or weakness appears"],
    escalation: ["Surgical or injection opinion if disabling symptoms persist or deficit progresses", "Urgent referral for cauda equina features", "Vascular referral if pulses are reduced"],
  },
  {
    slug: "patellar-tendinopathy", name: "Patellar Tendinopathy", category: "Sports & Lower Limb",
    summary: "Isometric then heavy slow resistance loading, with load management, followed by an energy-storage phase before return to jumping. Passive treatments are adjuncts, and injections are not first-line.",
    assessment: ["Pain at the inferior pole of the patella and load history", "Single-leg decline squat and hop provocation", "Quadriceps, hip and calf strength", "Jump and landing mechanics", "VISA-P"],
    redFlags: ["Sudden pop or loss of extension", "Fracture suspicion", "Hot swollen joint or fever", "Constant night pain"],
    outcomeMeasures: ["VISA-P", "Single-leg decline squat pain", "Quadriceps strength", "Hop tests"],
    modalities: ["Extracorporeal shockwave: adjunct with mixed evidence", "Patellar tendon strap: short-term relief during sport", "Corticosteroid injection: short-term relief but worse medium-term outcomes in one trial", "Ultrasound and laser: not routinely recommended"],
    manualTherapy: ["Soft-tissue work to the quadriceps as an adjunct", "Avoid deep friction on a sore tendon", "Ankle or hip mobilisation only if a limitation affects loading"],
    exercises: ["Isometric knee extension or squat holds", "Heavy slow resistance squats and leg press", "Calf and hip strengthening", "Plyometric progression and sport drills"],
    homePlan: ["Perform exercises 3 days per week", "Keep jumping within an agreed pain limit", "Monitor pain after loading, and expect settling within 24 hours"],
    progression: ["Move from isometric to heavy slow resistance when pain on decline squat reduces", "Add plyometrics when strength is near the other side and daily loading is comfortable", "Regress load if pain persists beyond 24 hours"],
    escalation: ["Medical or sports medicine review for suspected tear or rupture", "Specialist opinion if a well-delivered programme over at least 12 weeks fails"],
  },
  {
    slug: "mcl-injury", name: "Medial Collateral Ligament (MCL) Injury", category: "Sports & Lower Limb",
    summary: "Isolated MCL sprains usually heal with early range, walking and strengthening. Grade the injury, always test the cruciates, and use criteria-based return to sport.",
    assessment: ["Mechanism and swelling timing", "Valgus stress at 0 and 30 degrees", "Lachman and other cruciate tests", "Joint line palpation and effusion", "Range, strength and weight-bearing ability"],
    redFlags: ["Suspected fracture or inability to bear weight", "Locked knee", "Neurovascular compromise or suspected dislocation", "Laxity at full extension suggesting a combined injury"],
    outcomeMeasures: ["IKDC subjective form or KOOS", "Range of motion", "Hop and strength symmetry", "NPRS"],
    modalities: ["Cryotherapy for short-term comfort", "NMES for quadriceps activation if voluntary activation is poor", "Ultrasound and laser not routinely recommended"],
    manualTherapy: ["Gentle soft-tissue and joint mobilisation as an adjunct", "Avoid valgus stretching of the ligament early", "Patellar mobilisation if restricted"],
    exercises: ["Early range of motion and quadriceps activation", "Progressive lower-limb strengthening", "Balance and proprioception", "Agility and sport-specific drills"],
    homePlan: ["Do range exercises several times daily", "Walk as tolerated with a brace if advised", "Strengthen 3 days per week"],
    progression: ["Progress strength load when swelling and pain settle", "Add agility when single-leg control is good", "Return to contact sport after strength, hop and confidence criteria are met"],
    escalation: ["Imaging and orthopaedic review for suspected combined injury or grade III laxity with instability", "Urgent review for neurovascular concerns"],
  },
  {
    slug: "pelvic-girdle-pain", name: "Pelvic Girdle Pain (Sacroiliac Region)", category: "Spine & MSK",
    summary: "Education, activity modification and progressive strengthening are the base, with a support belt for short-term pain relief in selected patients. Diagnosis uses a composite of provocation tests rather than a single test.",
    assessment: ["Pain mapping and aggravating tasks (stairs, turning, single-leg stance)", "Composite of provocation tests", "Active straight leg raise with and without compression", "Lumbar spine and hip examination", "Inflammatory and obstetric red flags"],
    redFlags: ["Fever or severe unrelenting pain", "Cancer history or weight loss", "Cauda equina features", "Obstetric complications or bleeding", "Inflammatory pattern in younger adults"],
    outcomeMeasures: ["Pelvic girdle questionnaire or Oswestry Disability Index", "NPRS", "Active straight leg raise effort rating", "Walking and stair tolerance"],
    modalities: ["Pelvic support belt: short-term pain relief in some patients", "Heat or TENS for short-term comfort", "Ultrasound not recommended"],
    manualTherapy: ["Soft-tissue and joint techniques as adjuncts for short-term relief", "Muscle energy techniques with limited evidence", "Avoid forceful techniques in pregnancy", "Thrust manipulation not routinely recommended"],
    exercises: ["Deep trunk and hip activation", "Progressive gluteal and trunk strengthening", "Functional tasks (sit-to-stand, stairs, single-leg stance)", "Graded walking and postpartum return to exercise"],
    homePlan: ["Avoid asymmetric loading (for example standing on one leg to dress)", "Keep activity within a comfortable range", "Strengthen 2-3 days per week"],
    progression: ["Increase load when active straight leg raise effort and pain reduce", "Add single-leg and impact tasks before running", "Regress if pain spreads or night pain increases"],
    escalation: ["Medical review for obstetric or inflammatory concerns", "Imaging only when serious or inflammatory causes are suspected"],
  },
];

export const expansionTreatmentPlanGuides: Record<string, TreatmentPlanGuide> = {
  "gluteal-tendinopathy": {
    clinicalLogic: [
      "Lateral hip pain is not automatically bursitis. Check the hip joint and lumbar spine, then think of the gluteal tendons as compressed and overloaded structures.",
      "Reduce compressive positions first, then rebuild tendon capacity gradually. Stretching the iliotibial band into adduction can aggravate the problem.",
      "Judge progress by single-leg stance, stairs and night pain, not by tenderness alone.",
    ],
    firstSession: [
      "Record night pain, stairs pain, the single-leg stance time and the pain intensity.",
      "Teach the compressive positions to avoid and give a simple pillow and sitting strategy.",
      "Start isometric abduction at a tolerable level and ask about the response in 24 hours.",
      "Screen the hip joint and lumbar spine and explain the timeline of weeks to months.",
    ],
    exerciseDose: [
      "Isometric abduction: for example 5 repetitions of 30-45 seconds, once or twice daily, as an example needing individualisation.",
      "Strengthening: 2-3 sets of 8-12 repetitions, 3 days per week, adding load slowly as an example needing individualisation.",
      "Accept mild pain during exercise if it settles within 24 hours; reduce load if next-day pain is clearly worse.",
    ],
    manualApplication: [
      "Use soft-tissue or joint techniques only as an adjunct when they allow better exercise tolerance.",
      "Avoid deep pressure on the trochanter that compresses the tendon.",
      "Reassess single-leg stance or stairs after any manual technique and keep it only if it helps.",
    ],
    modalityDose: [
      "Dosage parameters for shockwave or laser are not given here because evidence for parameters in this condition is limited. Follow professional guidance.",
      "Corticosteroid injection is a medical decision and should be combined with an exercise plan.",
    ],
    progressionRules: [
      "Progress from isometric to isotonic to single-leg and impact loading as pain and function allow.",
      "Return to running with a graded plan only after stairs and single-leg stance are comfortable.",
      "Regress load if next-day pain rises and does not settle within 24 hours.",
    ],
    commonMistakes: [
      "Stretching the iliotibial band aggressively.",
      "Using side-lying exercises that compress the painful side.",
      "Relying on injection without a loading plan.",
      "Missing hip osteoarthritis or lumbar referral.",
    ],
    patientEducation: [
      "Explain that the tendon is overloaded and compressed, and that it can adapt.",
      "Explain that improvement takes weeks to months.",
      "Teach the positions to avoid and how to modify sitting and sleep.",
    ],
  },
  "whiplash-associated-disorder": {
    clinicalLogic: [
      "Rule out fracture and neurological injury before examining movement.",
      "Most people improve, and reassurance with active movement is preferred to collars or rest.",
      "Use early pain, disability and distress to decide how much support to offer.",
    ],
    firstSession: [
      "Apply validated screening rules and record neurology.",
      "Explain the expected recovery and the role of movement.",
      "Start gentle active range and a driving or work plan.",
    ],
    exerciseDose: [
      "Active range: 5-10 repetitions in each direction, several times daily, as an example needing individualisation.",
      "Strengthening: 2-3 sets of 8-12 repetitions, 2-3 days per week, as a typical starting point.",
    ],
    manualApplication: [
      "Use mobilisation only as an adjunct if it improves a comparable sign.",
      "Avoid cervical manipulation early after trauma.",
    ],
    modalityDose: [
      "Dosage parameters for this modality are not given because reliable evidence for parameters in this condition is lacking. Follow professional guidance.",
    ],
    progressionRules: [
      "Increase exercise as irritability settles.",
      "Add graded exposure for feared activities.",
      "Review neurology if symptoms change.",
    ],
    commonMistakes: [
      "Using a collar or prolonged rest.",
      "Missing neurological signs.",
      "Ignoring distress and sleep.",
    ],
    patientEducation: [
      "Explain the generally favourable outlook.",
      "Teach activity pacing and flare plans.",
      "Explain when to seek urgent help.",
    ],
  },
  "lumbar-spinal-stenosis": {
    clinicalLogic: [
      "Neurogenic claudication is posture dependent, easing with flexion and worsening with extension.",
      "Exercise and walking are first-line, and imaging severity does not predict symptoms.",
      "Progressive deficit or cauda equina features need urgent review.",
    ],
    firstSession: [
      "Record walking time to symptoms and the posture response.",
      "Check neurology and pulses.",
      "Teach flexion-based positions and start cycling or walking.",
    ],
    exerciseDose: [
      "Cycling or flexion-biased exercise: for example 10-20 minutes daily, as an example needing individualisation.",
      "Strengthening: 2-3 sets of 8-12 repetitions, 2-3 days per week, as a typical starting point.",
    ],
    manualApplication: [
      "Use manual therapy only as an adjunct to exercise and walking.",
      "Avoid techniques that provoke leg symptoms.",
    ],
    modalityDose: [
      "Dosage parameters for this modality are not given because reliable evidence for parameters in this condition is lacking. Follow professional guidance.",
    ],
    progressionRules: [
      "Increase walking time gradually.",
      "Add load to strengthening as tolerated.",
      "Refer for surgical opinion if disabling symptoms persist.",
    ],
    commonMistakes: [
      "Prescribing repeated extension.",
      "Missing vascular claudication.",
      "Relying on imaging severity.",
    ],
    patientEducation: [
      "Explain that stenosis on imaging is common and often stable.",
      "Explain posture strategies that relieve symptoms.",
      "Explain falls prevention.",
    ],
  },
  "patellar-tendinopathy": {
    clinicalLogic: [
      "Tendons adapt to progressive load over months.",
      "Isometrics help early pain, and heavy slow resistance rebuilds capacity before plyometrics restore energy storage.",
      "Pain during loading may be acceptable if it settles within 24 hours.",
    ],
    firstSession: [
      "Record decline squat pain and VISA-P.",
      "Explain tendon load and the plan.",
      "Start isometric loading and adjust jumping volume.",
    ],
    exerciseDose: [
      "Isometrics: for example 5 repetitions of 30-45 seconds, once or twice daily, as an example needing individualisation.",
      "Heavy slow resistance: for example 3-4 sets of 6-15 repetitions, three days per week, as an example needing individualisation.",
    ],
    manualApplication: [
      "Use soft-tissue work only as a short-term adjunct.",
      "Avoid deep friction on a sore tendon.",
    ],
    modalityDose: [
      "Dosage parameters for this modality are not given because reliable evidence for parameters in this condition is lacking. Follow professional guidance.",
    ],
    progressionRules: [
      "Move to heavy slow resistance when pain on decline squat reduces.",
      "Add plyometrics when strength is near the other side.",
      "Regress if pain persists beyond 24 hours.",
    ],
    commonMistakes: [
      "Complete rest.",
      "Rapid return to jumping.",
      "Doing only passive treatments.",
    ],
    patientEducation: [
      "Explain that the tendon can adapt.",
      "Explain the timeline of at least 12 weeks.",
      "Explain pain monitoring.",
    ],
  },
  "mcl-injury": {
    clinicalLogic: [
      "Isolated MCL injuries have good healing capacity.",
      "Always test the cruciates and menisci.",
      "Return to sport is based on strength, hop and confidence criteria, not time alone.",
    ],
    firstSession: [
      "Grade valgus laxity and test the cruciates.",
      "Explain healing and early movement.",
      "Start range and quadriceps activation.",
    ],
    exerciseDose: [
      "Range exercises: 10 repetitions, several times daily, as an example needing individualisation.",
      "Strengthening: 2-3 sets of 8-12 repetitions, 3 days per week, as a typical starting point.",
    ],
    manualApplication: [
      "Use gentle soft-tissue or joint techniques as adjuncts.",
      "Avoid valgus stretching in the early phase.",
    ],
    modalityDose: [
      "Dosage parameters for this modality are not given because reliable evidence for parameters in this condition is lacking. Follow professional guidance.",
    ],
    progressionRules: [
      "Progress as swelling and pain settle.",
      "Add agility when single-leg control is good.",
      "Return to contact sport when strength, hop and confidence criteria are met.",
    ],
    commonMistakes: [
      "Missing a combined injury.",
      "Prolonged immobilisation.",
      "Returning too early.",
    ],
    patientEducation: [
      "Explain healing and why early movement helps.",
      "Explain brace use if advised.",
      "Explain return-to-sport criteria.",
    ],
  },
  "pelvic-girdle-pain": {
    clinicalLogic: [
      "Use a composite of provocation tests and the active straight leg raise instead of a single test.",
      "Provocation shows pain reproduction and does not prove the sacroiliac joint is the source.",
      "Education, activity modification and strengthening are the foundation.",
    ],
    firstSession: [
      "Map the pain and identify aggravating tasks.",
      "Perform the test composite and active straight leg raise.",
      "Teach load-sharing strategies and start gentle activation.",
    ],
    exerciseDose: [
      "Activation: 5-10 repetitions, several times daily, as an example needing individualisation.",
      "Strengthening: 2-3 sets of 8-12 repetitions, 2-3 days per week, as a typical starting point.",
    ],
    manualApplication: [
      "Use manual therapy gently and only as an adjunct.",
      "Avoid forceful techniques in pregnancy.",
    ],
    modalityDose: [
      "Dosage parameters for this modality are not given because reliable evidence for parameters in this condition is lacking. Follow professional guidance.",
    ],
    progressionRules: [
      "Increase load when active straight leg raise effort and pain reduce.",
      "Add single-leg tasks before running.",
      "Regress if pain spreads.",
    ],
    commonMistakes: [
      "Calling every positive test sacroiliac dysfunction.",
      "Using forceful manipulation in pregnancy.",
      "Ignoring the hip and lumbar spine.",
    ],
    patientEducation: [
      "Explain the favourable outlook.",
      "Explain load-sharing strategies.",
      "Explain when to seek urgent help.",
    ],
  },
};
