import { mskConditions } from "./msk-injury-hub";
import { treatmentPlans } from "./treatment-plans";
import { mskSpecialTests } from "./msk-special-tests";
import { mskConditionDepth } from "./msk-condition-depth";
import { mskTestEvidence } from "./msk-test-evidence";
import { treatmentPlanEvidence } from "./treatment-plan-evidence";
import { EVIDENCE_REFS } from "./msk-evidence-refs";

/**
 * Cross-links between MSK conditions, treatment plans and special tests.
 * Source of truth: msk-condition-depth.ts (condition -> plan, condition -> tests).
 * Reverse lookups are derived here. Any broken id throws at build time, so no dead link can ship.
 */
const conditionSlugs = new Set(mskConditions.map((c) => c.slug));
const planSlugs = new Set(treatmentPlans.map((p) => p.slug));
const testById = new Map(mskSpecialTests.map((t) => [t.id, t]));

for (const [slug, depth] of Object.entries(mskConditionDepth)) {
  if (!conditionSlugs.has(slug)) throw new Error("Depth entry for unknown condition: " + slug);
  if (depth.planSlug && !planSlugs.has(depth.planSlug)) throw new Error("Unknown plan " + depth.planSlug + " linked from " + slug);
  for (const id of depth.testIds) if (!testById.has(id)) throw new Error("Unknown test id " + id + " linked from " + slug);
  for (const key of depth.refs) if (!(key in EVIDENCE_REFS)) throw new Error("Unknown reference " + key + " in " + slug);
}
for (const [id, ev] of Object.entries(mskTestEvidence)) {
  if (!testById.has(id)) throw new Error("Evidence entry for unknown test: " + id);
  for (const rel of ev.relatedTestIds) if (!testById.has(rel)) throw new Error("Unknown related test " + rel + " in " + id);
  for (const key of ev.refs) if (!(key in EVIDENCE_REFS)) throw new Error("Unknown reference " + key + " in test " + id);
}
for (const [slug, ev] of Object.entries(treatmentPlanEvidence)) {
  if (!planSlugs.has(slug)) throw new Error("Plan evidence for unknown plan: " + slug);
  for (const key of ev.refs) if (!(key in EVIDENCE_REFS)) throw new Error("Unknown reference " + key + " in plan " + slug);
}

export function getConditionDepth(slug: string) {
  return mskConditionDepth[slug] ?? null;
}

export function getLinkedPlan(conditionSlug: string) {
  const slug = mskConditionDepth[conditionSlug]?.planSlug;
  const plan = treatmentPlans.find((p) => p.slug === slug);
  return plan ? { slug: plan.slug, name: plan.name } : null;
}

export function getLinkedTests(conditionSlug: string) {
  const ids = mskConditionDepth[conditionSlug]?.testIds ?? [];
  return ids.map((id) => {
    const t = testById.get(id)!;
    return { id: t.id, name: t.name, region: t.region };
  });
}

export function getConditionsForPlan(planSlug: string) {
  return mskConditions
    .filter((c) => mskConditionDepth[c.slug]?.planSlug === planSlug)
    .map((c) => ({ slug: c.slug, name: c.name }));
}

export function getTestsForPlan(planSlug: string) {
  const seen = new Map<string, { id: string; name: string; region: string }>();
  for (const c of getConditionsForPlan(planSlug)) {
    for (const t of getLinkedTests(c.slug)) seen.set(t.id, t);
  }
  return Array.from(seen.values());
}

export function getConditionsForTest(testId: string) {
  return mskConditions
    .filter((c) => mskConditionDepth[c.slug]?.testIds.includes(testId))
    .map((c) => ({ slug: c.slug, name: c.name }));
}
