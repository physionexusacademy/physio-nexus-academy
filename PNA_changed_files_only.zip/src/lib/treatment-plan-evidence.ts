import type { RefKey } from "./msk-evidence-refs";

/**
 * Critical appraisal layer for MSK treatment plans, keyed by plan slug.
 * It adds goals, an explicit verdict for each modality, stop/modify rules and references.
 * No treatment parameters are invented: where evidence for parameters is weak, the entry says so.
 */
export type ModalityVerdict = "Supported" | "Adjunct only" | "Short-term symptom relief only" | "Limited evidence" | "Not routinely recommended";

export type PlanEvidence = {
  goals: string[];
  modalityAppraisal: { modality: string; verdict: ModalityVerdict; note: string }[];
  stopOrModify: string[];
  refs: RefKey[];
};

const p = (goals: string[], modalityAppraisal: PlanEvidence["modalityAppraisal"], stopOrModify: string[], refs: RefKey[]): PlanEvidence => ({ goals, modalityAppraisal, stopOrModify, refs });

const GENERIC_STOP = "Stop or modify any intervention that provokes spreading pain, new neurological symptoms or a clearly worse comparable sign on reassessment.";

export const treatmentPlanEvidence: Record<string, PlanEvidence> = {
  "mechanical-neck-pain": p(
    ["Reduce pain enough to restore neck movement", "Build neck and scapular capacity", "Return to work and leisure with a self-management plan"],
    [
      { modality: "Heat", verdict: "Short-term symptom relief only", note: "Comfort before movement; no evidence it changes long-term outcomes." },
      { modality: "TENS", verdict: "Short-term symptom relief only", note: "May reduce pain temporarily; should not replace exercise." },
      { modality: "Therapeutic ultrasound", verdict: "Not routinely recommended", note: "No convincing added benefit over exercise and education." },
    ],
    [GENERIC_STOP, "Stop cervical manipulation or end-range techniques if dizziness, visual change, speech or facial symptoms occur and seek urgent medical help."],
    ["blanpied2017", "gross2015ex", "gross2015manip", "ifompt2023"]),
  "cervical-radiculopathy": p(
    ["Monitor neurology and settle arm symptoms", "Restore neck and upper-quarter function", "Escalate promptly if deficit progresses"],
    [
      { modality: "Mechanical or manual traction", verdict: "Limited evidence", note: "Use as a symptom-response trial only; relief on the distraction test may guide, but benefit is not established." },
      { modality: "TENS or heat", verdict: "Short-term symptom relief only", note: "Comfort adjunct." },
      { modality: "Neurodynamic mobilisation", verdict: "Adjunct only", note: "Sliders before tensioners; evidence is limited and low certainty." },
    ],
    [GENERIC_STOP, "Refer urgently for progressive weakness, myelopathic signs or loss of bladder or bowel control."],
    ["wainner2003", "thoomes2013", "blanpied2017"]),
  "nonspecific-low-back-pain": p(
    ["Reassure and keep the patient active", "Restore function and confidence in movement", "Reduce recurrence and manage flares"],
    [
      { modality: "Heat", verdict: "Short-term symptom relief only", note: "Evidence from acute low back pain suggests short-term relief." },
      { modality: "TENS", verdict: "Short-term symptom relief only", note: "Certainty of evidence is low; no clear long-term benefit." },
      { modality: "Therapeutic ultrasound", verdict: "Not routinely recommended", note: "Review of chronic low back pain found no meaningful benefit." },
    ],
    [GENERIC_STOP, "Refer urgently for cauda equina features or progressive neurological loss."],
    ["george2021", "niceNG59", "french2006", "ebadi2014", "johnson2022"]),
  "lumbar-radiculopathy": p(
    ["Keep neurology stable or improving", "Reduce leg pain and restore function", "Return to work and activity"],
    [
      { modality: "Heat or TENS", verdict: "Short-term symptom relief only", note: "Comfort adjunct." },
      { modality: "Mechanical traction", verdict: "Limited evidence", note: "Inconsistent results; not routinely recommended." },
    ],
    [GENERIC_STOP, "Stop peripheralising movements and refer urgently for cauda equina features or progressive weakness."],
    ["niceNG59", "lewis2015", "vanderwindt2010"]),
  "knee-osteoarthritis": p(
    ["Reduce pain and improve function", "Support weight management and physical activity", "Encourage long-term self-management"],
    [
      { modality: "Exercise therapy", verdict: "Supported", note: "Cochrane review shows pain and function benefit." },
      { modality: "TENS", verdict: "Short-term symptom relief only", note: "Variable evidence; adjunct." },
      { modality: "Therapeutic ultrasound and laser", verdict: "Not routinely recommended", note: "Evidence is weak and inconsistent." },
    ],
    [GENERIC_STOP, "Seek medical review for a hot, swollen joint or rapid deterioration."],
    ["fransen2015"]),
  "hip-osteoarthritis": p(
    ["Reduce pain and improve walking function", "Maintain hip strength and range", "Support self-management"],
    [
      { modality: "Heat or TENS", verdict: "Short-term symptom relief only", note: "Comfort adjunct." },
      { modality: "Manual therapy", verdict: "Adjunct only", note: "Combine with exercise; benefit beyond exercise alone is uncertain." },
    ],
    [GENERIC_STOP, "Refer if night pain increases, function declines markedly or red flags emerge."],
    ["sutlive2008"]),
  "patellofemoral-pain": p(
    ["Reduce pain with a load-management plan", "Build knee and hip strength", "Return to sport"],
    [
      { modality: "Foot orthoses", verdict: "Adjunct only", note: "May give short-term benefit in selected patients; combine with exercise." },
      { modality: "Patellar taping", verdict: "Short-term symptom relief only", note: "May reduce pain during early rehabilitation." },
      { modality: "Electrotherapy, ultrasound and laser", verdict: "Not routinely recommended", note: "No consistent evidence of added benefit." },
    ],
    [GENERIC_STOP, "Modify exercise depth or load if pain exceeds an agreed moderate level or does not settle in 24 hours."],
    ["willy2019"]),
  "lateral-ankle-sprain": p(
    ["Protect briefly then restore movement and weight-bearing early", "Rebuild strength and balance", "Prevent recurrence"],
    [
      { modality: "Cryotherapy", verdict: "Short-term symptom relief only", note: "Evidence for ice in acute soft tissue injury is limited, and it should not delay loading." },
      { modality: "Bracing or taping", verdict: "Supported", note: "Guidelines support external support for some patients, especially return to sport." },
      { modality: "Ultrasound and laser", verdict: "Not routinely recommended", note: "Evidence is limited." },
    ],
    [GENERIC_STOP, "Re-image or refer if weight-bearing remains impossible or if instability persists."],
    ["martin2021ankle", "bleakley2004", "vandijk1996"]),
  "achilles-tendinopathy": p(
    ["Reduce pain and build tendon capacity", "Restore calf strength and endurance", "Return to running and jumping"],
    [
      { modality: "Extracorporeal shockwave", verdict: "Adjunct only", note: "Some evidence as an addition to exercise; heterogeneous parameters and results." },
      { modality: "Heel lifts or orthoses", verdict: "Short-term symptom relief only", note: "Selected patients." },
      { modality: "Ultrasound and laser", verdict: "Limited evidence", note: "Inconsistent results; not routinely recommended." },
    ],
    [GENERIC_STOP, "Refer if a sudden pop, palpable gap or loss of push-off occurs."],
    ["martin2018achilles", "beyer2015", "manibabu2015"]),
  "plantar-heel-pain": p(
    ["Reduce first-step pain", "Build foot and calf capacity", "Return to full activity"],
    [
      { modality: "Foot orthoses and taping", verdict: "Short-term symptom relief only", note: "Selected patients; combine with exercise." },
      { modality: "Extracorporeal shockwave", verdict: "Adjunct only", note: "Considered for persistent cases; results are mixed." },
      { modality: "Ultrasound and laser", verdict: "Limited evidence", note: "Not routinely recommended." },
    ],
    [GENERIC_STOP, "Investigate if pain is constant, night-related or suggests stress fracture or nerve entrapment."],
    ["koc2023"]),
  "adhesive-capsulitis": p(
    ["Control pain and keep the shoulder moving", "Regain range in the stiff phase", "Restore function"],
    [
      { modality: "Corticosteroid injection (medical)", verdict: "Adjunct only", note: "May help pain, especially early; long-term benefit is uncertain." },
      { modality: "Heat or TENS", verdict: "Short-term symptom relief only", note: "Comfort adjunct." },
      { modality: "Ultrasound and laser", verdict: "Limited evidence", note: "Not routinely recommended." },
    ],
    [GENERIC_STOP, "Reduce stretch intensity if night pain increases or pain lasts after exercise."],
    ["kelley2013", "page2014", "rangan2020"]),
  "rotator-cuff-related-shoulder-pain": p(
    ["Reduce pain and restore active function", "Build cuff and scapular capacity", "Return to work and sport"],
    [
      { modality: "Therapeutic ultrasound", verdict: "Not routinely recommended", note: "No consistent evidence of meaningful added benefit." },
      { modality: "TENS or heat", verdict: "Short-term symptom relief only", note: "Comfort adjunct." },
      { modality: "Manual therapy", verdict: "Adjunct only", note: "May ease pain short-term; exercise remains primary." },
    ],
    [GENERIC_STOP, "Refer for traumatic weakness, suspected large tear or neurological signs."],
    ["hermans2013", "park2005", "kuhn2013"]),
  "lateral-elbow-tendinopathy": p(
    ["Reduce pain and improve grip", "Build tendon capacity", "Return to work and sport"],
    [
      { modality: "Counterforce strap or brace", verdict: "Short-term symptom relief only", note: "Temporary support during activity." },
      { modality: "Manual therapy (elbow mobilisation with movement)", verdict: "Adjunct only", note: "Some evidence of short-term pain benefit." },
      { modality: "Ultrasound and laser", verdict: "Not routinely recommended", note: "Limited and inconsistent evidence." },
    ],
    [GENERIC_STOP, "Check neck and radial nerve if there is no improvement in a well-delivered loading programme."],
    ["coombes2009", "bisset2015"]),
  "acl-reconstruction-rehabilitation": p(
    ["Restore range, swelling control and quadriceps function early", "Progress to running, agility and sport tasks", "Return to sport using objective criteria"],
    [
      { modality: "Neuromuscular electrical stimulation", verdict: "Adjunct only", note: "Can help early quadriceps activation when voluntary activation is poor." },
      { modality: "Cryotherapy", verdict: "Short-term symptom relief only", note: "Comfort and swelling aid." },
    ],
    ["Follow surgeon protocol restrictions for graft and meniscal or cartilage procedures.", GENERIC_STOP],
    ["grindem2016", "kyritsis2016"]),
  "hamstring-strain": p(
    ["Restore pain-free movement and strength", "Return to sprinting progressively", "Prevent re-injury"],
    [
      { modality: "Cryotherapy", verdict: "Short-term symptom relief only", note: "Comfort in the first days." },
      { modality: "Ultrasound and laser", verdict: "Not routinely recommended", note: "Limited evidence of benefit." },
    ],
    [GENERIC_STOP, "Refer if a large gap, proximal avulsion features or severe bruising and weakness are present."],
    ["askling2013"]),
  "carpal-tunnel-syndrome": p(
    ["Reduce night symptoms and numbness", "Maintain function and grip", "Escalate when deficit progresses"],
    [
      { modality: "Night wrist splint", verdict: "Supported", note: "Recommended conservative option in guidelines." },
      { modality: "Nerve gliding", verdict: "Adjunct only", note: "Low-certainty evidence." },
      { modality: "Ultrasound and laser", verdict: "Limited evidence", note: "Inconsistent evidence; not routinely recommended." },
    ],
    [GENERIC_STOP, "Refer for thenar wasting, constant numbness or severe symptoms."],
    ["erickson2019", "macdermid2004"]),
  "de-quervain-tenosynovitis": p(
    ["Reduce pain and swelling", "Restore grip and thumb function", "Return to childcare and work tasks"],
    [
      { modality: "Thumb spica splint", verdict: "Short-term symptom relief only", note: "Used with load modification; evidence limited." },
      { modality: "Corticosteroid injection (medical)", verdict: "Adjunct only", note: "Often helpful for persistent pain, with risks." },
      { modality: "Ultrasound and laser", verdict: "Limited evidence", note: "Not routinely recommended." },
    ],
    [GENERIC_STOP, "Refer if there is no improvement after structured conservative care."],
    ["ilyas2007"]),
  "gluteal-tendinopathy": p(
    ["Reduce tendon compression and pain", "Build abductor strength and tendon capacity", "Return to walking, stairs and sport"],
    [
      { modality: "Corticosteroid injection (medical)", verdict: "Adjunct only", note: "Short-term relief; education plus exercise was better at longer follow-up in one trial." },
      { modality: "Extracorporeal shockwave", verdict: "Limited evidence", note: "Mixed evidence." },
      { modality: "Ultrasound and laser", verdict: "Not routinely recommended", note: "Evidence is limited." },
    ],
    [GENERIC_STOP, "Seek medical review for night pain with systemic features or fracture risk."],
    ["mellor2018", "grimaldi2015"]),
  "whiplash-associated-disorder": p(
    ["Exclude serious injury, then reduce fear and keep the patient active", "Restore neck movement and capacity", "Prevent persistent disability"],
    [
      { modality: "Soft collar", verdict: "Not routinely recommended", note: "Prolonged use may slow recovery; short-term use only on specific advice." },
      { modality: "Heat or TENS", verdict: "Short-term symptom relief only", note: "Comfort adjunct." },
      { modality: "Therapeutic ultrasound", verdict: "Not routinely recommended", note: "No convincing added benefit." },
    ],
    [GENERIC_STOP, "Refer urgently for fracture criteria, progressive neurological deficit or vascular symptoms."],
    ["bussieres2016", "spitzer1995", "ifompt2023"]),
  "lumbar-spinal-stenosis": p(
    ["Maintain walking and function", "Reduce leg symptoms and falls risk", "Identify patients who need surgical review"],
    [
      { modality: "Heat or TENS", verdict: "Short-term symptom relief only", note: "Comfort adjunct." },
      { modality: "Traction", verdict: "Limited evidence", note: "Evidence is limited and inconsistent." },
      { modality: "Therapeutic ultrasound", verdict: "Not routinely recommended", note: "No evidence of added benefit." },
    ],
    [GENERIC_STOP, "Refer urgently for cauda equina features or rapidly progressive weakness."],
    ["kreiner2013", "zaina2016"]),
  "patellar-tendinopathy": p(
    ["Reduce pain with load management", "Rebuild tendon and quadriceps capacity", "Return to jumping and sport"],
    [
      { modality: "Extracorporeal shockwave", verdict: "Adjunct only", note: "Mixed evidence as an addition to exercise." },
      { modality: "Corticosteroid injection (medical)", verdict: "Limited evidence", note: "Short-term relief but worse medium-term outcomes than loading in one trial." },
      { modality: "Ultrasound and laser", verdict: "Not routinely recommended", note: "Limited evidence." },
    ],
    [GENERIC_STOP, "Refer for suspected rupture or if there is no response to a well-delivered programme."],
    ["malliaras2015", "kongsgaard2009", "manibabu2015"]),
  "mcl-injury": p(
    ["Restore range and walking early", "Rebuild strength and neuromuscular control", "Return to sport using objective criteria"],
    [
      { modality: "Hinged brace", verdict: "Adjunct only", note: "May be used in higher grades for early protection, guided by the clinician." },
      { modality: "Neuromuscular electrical stimulation", verdict: "Adjunct only", note: "Useful if quadriceps activation is poor." },
      { modality: "Ultrasound and laser", verdict: "Not routinely recommended", note: "Limited evidence." },
    ],
    [GENERIC_STOP, "Refer for suspected combined ligament injury or neurovascular concerns."],
    ["logerstedt2017", "phisitkul2006"]),
  "pelvic-girdle-pain": p(
    ["Reduce pain with load-sharing strategies", "Restore strength and load transfer", "Return to full daily and work activity"],
    [
      { modality: "Pelvic support belt", verdict: "Short-term symptom relief only", note: "May reduce pain during activity in some patients." },
      { modality: "Heat or TENS", verdict: "Short-term symptom relief only", note: "Comfort adjunct." },
      { modality: "Therapeutic ultrasound", verdict: "Not routinely recommended", note: "No evidence of benefit." },
    ],
    [GENERIC_STOP, "Seek medical review for obstetric concerns, fever or inflammatory features."],
    ["vleeming2008", "laslett2005"]),
};
