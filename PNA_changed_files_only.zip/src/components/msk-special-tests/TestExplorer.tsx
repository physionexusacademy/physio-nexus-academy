"use client";

import { useEffect, useMemo, useState } from "react";
import { ArrowRight, CheckCircle2, ChevronDown, ClipboardCheck, Eye, Hand, MoveRight, RotateCcw, Search, ShieldAlert, Stethoscope, Target, UserRound, AlertTriangle } from "lucide-react";
import { MSK_TEST_REGIONS } from "@/lib/msk-special-tests-types";
import type { GuidedMskSpecialTest } from "@/lib/msk-special-tests";

type Region = "All tests" | (typeof MSK_TEST_REGIONS)[number];

export type TestEvidenceView = {
  strength: string;
  alsoKnownAs: string[];
  anatomy: string;
  usefulFor: string;
  accuracy: string;
  variation: string;
  negativeMeaning: string;
  combineWith: string;
  related: { id: string; name: string }[];
  conditions: { slug: string; name: string }[];
  references: { citation: string; href: string; kind: string; verified: boolean }[];
};

export function TestExplorer({ tests, evidence = {}, numbersNote = "" }: { tests: GuidedMskSpecialTest[]; evidence?: Record<string, TestEvidenceView>; numbersNote?: string }) {
  const [query, setQuery] = useState("");
  const [region, setRegion] = useState<Region>("All tests");
  const [visibleCount, setVisibleCount] = useState(12);
  const [expanded, setExpanded] = useState<string[]>([]);

  // Allow deep links such as /msk-special-tests?q=Lachman from condition pages.
  useEffect(() => {
    const q = new URLSearchParams(window.location.search).get("q");
    if (q) setQuery(q.slice(0, 120));
  }, []);

  const counts = useMemo(() => new Map(MSK_TEST_REGIONS.map((item) => [item, tests.filter((t) => t.region === item).length])), [tests]);
  const matches = useMemo(() => {
    const search = query.trim().toLocaleLowerCase();
    return tests.filter((test) => {
      if (region !== "All tests" && test.region !== region) return false;
      if (!search) return true;
      return [test.name, test.region, test.purpose, test.position, test.positive, test.meaning, ...test.steps, test.technique.hands, test.technique.force, test.technique.therapist].join(" ").toLocaleLowerCase().includes(search);
    });
  }, [tests, region, query]);
  const visible = matches.slice(0, visibleCount);
  const selectRegion = (next: Region) => { setRegion(next); setVisibleCount(12); setExpanded([]); };
  const toggle = (id: string) => setExpanded((before) => before.includes(id) ? before.filter((v) => v !== id) : [...before, id]);
  const reset = () => { setQuery(""); setRegion("All tests"); setVisibleCount(12); setExpanded([]); };

  return (
    <div className="grid items-start gap-7 lg:grid-cols-[240px_minmax(0,1fr)]">
      <aside className="rounded-3xl border border-slate-200 bg-white p-4 shadow-[0_12px_45px_-36px_rgba(10,47,62,0.4)] lg:sticky lg:top-28" aria-label="Filter tests by body region">
        <p className="px-3 pt-2 text-xs font-bold uppercase tracking-[0.15em] text-teal-700">Body regions</p>
        <div className="mt-3 space-y-1">
          {(["All tests", ...MSK_TEST_REGIONS] as Region[]).map((name) => {
            const selected = region === name;
            const count = name === "All tests" ? tests.length : counts.get(name) || 0;
            return (
              <button
                type="button" key={name} onClick={() => selectRegion(name)} aria-pressed={selected}
                className={"flex w-full items-center justify-between gap-2 rounded-xl px-3 py-2.5 text-left text-sm font-semibold transition " +
                  (selected ? "bg-teal-700 text-white shadow-sm" : "text-slate-600 hover:bg-slate-50 hover:text-teal-800")}
              >
                <span className="leading-5">{name}</span>
                <span className={"min-w-7 rounded-md px-1.5 py-0.5 text-center text-xs tabular-nums " + (selected ? "bg-white/20 text-white" : "bg-slate-100 text-slate-500")}>{count}</span>
              </button>
            );
          })}
        </div>
        <div className="mt-5 border-t border-slate-100 px-3 pt-4 text-xs leading-6 text-slate-500">
          Choose a region or search by test, structure, symptom or technique.
        </div>
      </aside>

      <section aria-label="Searchable MSK special tests">
        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-[0_12px_45px_-38px_rgba(10,47,62,0.3)] sm:p-5">
          <label htmlFor="msk-test-search" className="mb-2 block text-xs font-bold uppercase tracking-widest text-slate-600">Find a clinical test</label>
          <div className="relative">
            <Search className="pointer-events-none absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-teal-700" aria-hidden="true"/>
            <input
              id="msk-test-search" type="search" value={query}
              onChange={(e) => {setQuery(e.target.value);setVisibleCount(12);setExpanded([]);}}
              placeholder="Search Lachman, shoulder, ACL, nerve, instability..."
              className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3.5 pl-12 text-sm font-medium text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-teal-500 focus:bg-white focus:ring-4 focus:ring-teal-500/10"
            />
          </div>
          <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
            <p className="text-sm text-slate-600"><span className="font-bold text-teal-800">{matches.length}</span> {matches.length===1?"test":"tests"} found</p>
            {(query || region !== "All tests") && <button onClick={reset} type="button" className="inline-flex items-center gap-1.5 text-xs font-bold text-teal-800 hover:underline"><RotateCcw className="h-3.5 w-3.5"/>Clear filters</button>}
          </div>
        </div>

        {visible.length === 0 ? (
          <div className="mt-5 rounded-3xl border border-slate-200 bg-white p-12 text-center">
            <Search className="mx-auto h-8 w-8 text-teal-700"/>
            <h2 className="mt-3 text-lg font-bold text-slate-900">No matching tests</h2>
            <p className="mt-2 text-sm text-slate-600">Try a different test name, body region, symptom or joint structure.</p>
            <button onClick={reset} type="button" className="mt-4 rounded-xl bg-teal-700 px-4 py-2.5 text-sm font-bold text-white">Show all tests</button>
          </div>
        ) : (
          <div className="mt-5 space-y-4">
            {visible.map((test, index) => {
              const open = expanded.includes(test.id);
              return (
                <article key={test.id} id={test.id} className="scroll-mt-28 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-[0_15px_35px_-32px_rgba(4,46,62,0.45)]">
                  <div className="p-5 sm:p-6">
                    <div className="flex flex-wrap items-center gap-2 text-xs font-bold">
                      <span className="rounded-full bg-teal-50 px-3 py-1 text-teal-800">{test.region}</span>
                      <span className="text-slate-400">TEST {String(index + 1).padStart(2,"0")}</span>
                    </div>
                    <h2 className="mt-3 font-serif text-xl font-bold leading-snug text-slate-900 sm:text-2xl">{test.name}</h2>
                    <p className="mt-2 text-sm leading-7 text-slate-600"><strong className="font-bold text-slate-800">Purpose:</strong> {test.purpose}</p>
                    <button
                      type="button" onClick={() => toggle(test.id)} aria-expanded={open} aria-controls={test.id + "-method"}
                      className="mt-4 inline-flex min-h-10 items-center gap-2 rounded-xl border border-teal-200 bg-teal-50 px-4 py-2 text-sm font-bold text-teal-800 transition hover:border-teal-300 hover:bg-teal-100 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-600"
                    >
                      {open ? "Hide technique" : "View hands, force & applying method"} <ChevronDown className={"h-4 w-4 transition-transform " + (open ? "rotate-180" : "")}/>
                    </button>
                  </div>
                  {open && <div id={test.id + "-method"} className="border-t border-slate-100 bg-slate-50/70 px-5 py-6 sm:px-6">
                    <div className="rounded-2xl border border-slate-200 bg-white p-4">
                      <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-teal-800"><Stethoscope className="h-4 w-4"/>Patient position</div>
                      <p className="mt-2 text-sm leading-7 text-slate-700">{test.position}</p>
                    </div>
                    <div className="mt-4 rounded-2xl border border-[#cfe8e5] bg-white p-4 shadow-[0_12px_30px_-24px_rgba(8,102,107,0.2)] sm:p-5" aria-label={"Therapist setup and hand placement for " + test.name}>
                      <div className="flex flex-wrap items-start justify-between gap-3">
                        <div>
                          <p className="text-[11px] font-bold uppercase tracking-[0.14em] text-teal-700">Clinical Technique Map</p>
                          <h3 className="mt-1 font-serif text-lg font-bold text-[#102e40]">Stand. Place hands. Apply force.</h3>
                        </div>
                        <span className="rounded-full border border-teal-100 bg-teal-50 px-3 py-1.5 text-[11px] font-bold text-teal-800">Therapist's viewpoint</span>
                      </div>
                      <div className="mt-4 space-y-3">
                        <div className="flex items-start gap-3 rounded-xl border border-slate-100 bg-[#f8fbfc] p-4">
                          <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-white text-teal-800 shadow-sm"><UserRound className="h-4 w-4" aria-hidden="true"/></span>
                          <div><h4 className="text-sm font-bold text-[#153a4a]">1. Where the therapist stands</h4><p className="mt-1.5 text-sm leading-7 text-slate-700">{test.technique.therapist}</p></div>
                        </div>
                        <div className="flex items-start gap-3 rounded-xl border border-slate-100 bg-[#f8fbfc] p-4">
                          <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-white text-teal-800 shadow-sm"><Hand className="h-4 w-4" aria-hidden="true"/></span>
                          <div><h4 className="text-sm font-bold text-[#153a4a]">2. Exact hand placement & stabilization</h4><p className="mt-1.5 text-sm leading-7 text-slate-700">{test.technique.hands}</p></div>
                        </div>
                        <div className="flex items-start gap-3 rounded-xl border border-[#cde9e6] bg-[#f0f9f7] p-4">
                          <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-white text-teal-800 shadow-sm"><MoveRight className="h-5 w-5" aria-hidden="true"/></span>
                          <div><h4 className="text-sm font-bold text-[#0c625e]">3. Force / movement direction</h4><p className="mt-1.5 text-sm leading-7 text-slate-800">{test.technique.force}</p></div>
                        </div>
                      </div>
                    </div>
                    <div className="mt-5">
                      <h3 className="flex items-center gap-2 text-base font-bold text-slate-900"><Hand className="h-5 w-5 text-teal-700"/>How to perform — step by step</h3>
                      <ol className="mt-4 space-y-3">
                        {test.steps.map((step, i) => <li key={i} className="flex gap-3 rounded-xl border border-slate-200 bg-white p-4 text-sm leading-7 text-slate-700">
                          <span className="flex h-7 w-7 flex-none items-center justify-center rounded-lg bg-teal-700 text-xs font-bold text-white">{i+1}</span><span>{step}</span>
                        </li>)}
                      </ol>
                    </div>
                    <div className="mt-4 rounded-2xl border border-sky-100 bg-gradient-to-br from-white to-sky-50/70 p-5">
                      <h3 className="flex items-center gap-2 text-sm font-bold text-[#133f52]"><Eye className="h-5 w-5 text-teal-700" aria-hidden="true"/>Picture the movement</h3>
                      <p className="mt-2 text-sm leading-8 text-slate-700">{test.technique.visualize}</p>
                    </div>
                    <div className="mt-3 flex items-start gap-3 rounded-xl border border-amber-100 bg-[#fffaf0] p-4">
                      <AlertTriangle className="mt-0.5 h-5 w-5 flex-none text-amber-700" aria-hidden="true"/>
                      <div><h3 className="text-sm font-bold text-amber-950">Common mistake — avoid this</h3><p className="mt-1.5 text-sm leading-7 text-amber-950">{test.technique.avoid}</p></div>
                    </div>
                    <div className="mt-5 grid gap-3 sm:grid-cols-2">
                      <div className="rounded-2xl border border-emerald-200 bg-emerald-50/70 p-4">
                        <h3 className="flex items-center gap-2 text-sm font-bold text-emerald-900"><CheckCircle2 className="h-4 w-4"/>Positive finding</h3>
                        <p className="mt-2 text-sm leading-7 text-slate-700">{test.positive}</p>
                      </div>
                      <div className="rounded-2xl border border-cyan-200 bg-cyan-50/70 p-4">
                        <h3 className="flex items-center gap-2 text-sm font-bold text-cyan-900"><Target className="h-4 w-4"/>What it means</h3>
                        <p className="mt-2 text-sm leading-7 text-slate-700">{test.meaning}</p>
                      </div>
                    </div>
                    {test.caution && <div className="mt-3 flex gap-3 rounded-2xl border border-amber-200 bg-amber-50/70 p-4">
                      <ShieldAlert className="mt-0.5 h-5 w-5 flex-none text-amber-700"/><div><h3 className="text-sm font-bold text-amber-900">Safety note</h3><p className="mt-1 text-sm leading-7 text-amber-950">{test.caution}</p></div>
                    </div>}
                    {evidence[test.id] && (() => {
                      const ev = evidence[test.id];
                      return (
                        <details className="mt-5 rounded-2xl border border-teal-200 bg-white p-4 sm:p-5">
                          <summary className="cursor-pointer text-sm font-bold text-teal-900">Evidence, accuracy &amp; limitations <span className="ml-2 rounded-full bg-teal-50 px-2.5 py-0.5 text-[11px] font-bold text-teal-800">{ev.strength} evidence</span></summary>
                          <div className="mt-4 space-y-3 text-sm leading-7 text-slate-700">
                            {ev.alsoKnownAs.length > 0 && <p><strong className="text-slate-900">Also known as:</strong> {ev.alsoKnownAs.join(", ")}</p>}
                            <p><strong className="text-slate-900">Relevant anatomy:</strong> {ev.anatomy}</p>
                            <p><strong className="text-slate-900">Useful for:</strong> {ev.usefulFor}</p>
                            <p><strong className="text-slate-900">Diagnostic accuracy evidence:</strong> {ev.accuracy}</p>
                            <p><strong className="text-slate-900">Why estimates vary / reliability:</strong> {ev.variation}</p>
                            <p><strong className="text-slate-900">If the test is negative:</strong> {ev.negativeMeaning}</p>
                            <p><strong className="text-slate-900">Combine with:</strong> {ev.combineWith}</p>
                            {ev.related.length > 0 && <div><strong className="text-slate-900">Related tests:</strong>
                              <div className="mt-2 flex flex-wrap gap-2">{ev.related.map((r) => <button key={r.id} type="button" onClick={() => { setQuery(r.name); setRegion("All tests"); setVisibleCount(12); setExpanded([]); }} className="rounded-full border border-teal-200 bg-teal-50 px-3 py-1 text-xs font-bold text-teal-800 hover:bg-teal-100">{r.name}</button>)}</div></div>}
                            {ev.conditions.length > 0 && <div><strong className="text-slate-900">Related conditions:</strong>
                              <div className="mt-2 flex flex-wrap gap-2">{ev.conditions.map((c) => <a key={c.slug} href={"/msk-injuries/" + c.slug} className="rounded-full border border-slate-200 bg-slate-50 px-3 py-1 text-xs font-bold text-slate-700 hover:border-teal-300">{c.name}</a>)}</div></div>}
                            {ev.references.length > 0 && <div><strong className="text-slate-900">References:</strong>
                              <ul className="mt-2 space-y-2">{ev.references.map((ref) => <li key={ref.href + ref.citation} className="text-xs leading-6 text-slate-600"><a href={ref.href} target="_blank" rel="noreferrer" className="font-semibold text-teal-800 hover:underline">{ref.citation}</a> <span className="text-slate-400">({ref.kind})</span> {!ref.verified && <span className="ml-1 rounded bg-amber-100 px-1.5 py-0.5 text-[10px] font-bold text-amber-900">Unverified - check source</span>}</li>)}</ul></div>}
                            {numbersNote && <p className="rounded-xl bg-amber-50 p-3 text-xs leading-6 text-amber-950">{numbersNote}</p>}
                          </div>
                        </details>
                      );
                    })()}
                    <p className="mt-4 text-xs leading-6 text-slate-500">Interpret findings with history, function, symptom behavior and other appropriate examinations. A single special test rarely confirms or excludes a condition.</p>
                  </div>}
                </article>
              );
            })}
          </div>
        )}

        {visibleCount < matches.length && <div className="mt-7 text-center">
          <button type="button" onClick={()=>setVisibleCount((n)=>n+12)} className="inline-flex items-center gap-2 rounded-xl bg-teal-700 px-6 py-3.5 text-sm font-bold text-white shadow-sm transition hover:bg-teal-800">
            Load more tests <ArrowRight className="h-4 w-4"/>
          </button>
          <p className="mt-2 text-xs text-slate-500">Showing {visible.length} of {matches.length}</p>
        </div>}
        <div className="mt-8 rounded-2xl border border-slate-200 bg-white p-5 text-sm leading-7 text-slate-600">
          <p className="flex items-center gap-2 font-bold text-slate-800"><ClipboardCheck className="h-5 w-5 text-teal-700"/>How to study a special test</p>
          <p className="mt-2">Remember the sequence: <strong>purpose → patient position → therapist position → exact hands → force direction → 3 steps → positive finding → meaning.</strong> Practise under competent clinical supervision, and screen for red flags before provocative examination.</p>
        </div>
      </section>
    </div>
  );
}
