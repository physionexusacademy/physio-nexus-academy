import assert from "node:assert/strict";
import { mskConditionIndex } from "../src/lib/msk-injury-index.ts";
import { mskConditions } from "../src/lib/msk-injury-hub.ts";
import { mskClinicalStories } from "../src/lib/msk-clinical-stories.ts";

const indexed = mskConditionIndex.map(({ slug }) => slug);
const clinical = mskConditions.map(({ slug }) => slug);
const authored = Object.keys(mskClinicalStories);
// Conditions added in the 2026 content upgrade that do not yet have a clinical story.
// Remove a slug from this list once its story is authored in msk-clinical-stories.ts.
const storyPending = new Set([
  "mechanical-neck-pain", "nonspecific-low-back-pain", "lumbar-radiculopathy-sciatica", "patellofemoral-pain",
  "achilles-tendinopathy", "plantar-heel-pain", "adhesive-capsulitis", "de-quervain-tenosynovitis", "gluteal-tendinopathy",
  "whiplash-associated-disorder", "cervicogenic-headache", "thoracic-spine-pain", "lumbar-spinal-stenosis", "pelvic-girdle-pain",
  "patellar-tendinopathy", "mcl-injury", "chronic-ankle-instability", "medial-epicondylalgia", "trigger-finger",
  "acromioclavicular-joint-injury", "proximal-biceps-tendinopathy", "pcl-injury", "spondylolysis-spondylolisthesis", "adductor-related-groin-pain",
]);
const storyRequired = indexed.filter((slug) => !storyPending.has(slug));
const unique = (items) => new Set(items).size === items.length;

assert.ok(unique(indexed), "Duplicate condition index slug");
assert.ok(unique(clinical), "Duplicate condition library slug");
assert.ok(unique(authored), "Duplicate authored story slug");
assert.deepEqual([...indexed].sort(), [...clinical].sort(), "Index and clinical library must match");
assert.deepEqual([...storyRequired].sort(), [...authored].sort(), "Every published condition needs its own story (or a storyPending entry)");

for (const slug of storyRequired) {
  const story = mskClinicalStories[slug];
  for (const field of [
    "headline", "scene", "dialogue", "clue", "twist", "aha",
    "patientTranslation", "clinicianReasoning", "rehabBridge", "question", "explanation",
  ]) {
    assert.ok(typeof story[field] === "string" && story[field].trim().length > 35,
      slug + ": missing/too-short " + field);
  }
  assert.ok(Array.isArray(story.options) && story.options.length === 3, slug + ": expected three choices");
  assert.ok(story.options.every((option) => typeof option === "string" && option.length > 15), slug + ": invalid option");
  assert.ok(Number.isInteger(story.answer) && story.answer >= 0 && story.answer < story.options.length,
    slug + ": invalid answer");
  assert.ok(new Set(story.options).size === 3, slug + ": duplicate choices");
}

console.log("MSK story validation passed: " + authored.length + " distinct cases match clinical guides and index (" + storyPending.size + " newer conditions pending stories).");
