// Validates the MSK conditions, treatment plans and special-tests content libraries.
// Usage: node scripts/validate-msk-content.mjs          (needs the "typescript" dev dependency; run npm ci first)
//        node scripts/validate-msk-content.mjs --inventory   (also writes docs/MSK_CONTENT_INVENTORY.md)
import { createRequire } from "node:module";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const require = createRequire(import.meta.url);
const ts = require("typescript");
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

// Minimal TypeScript loader for src/lib data modules (relative imports only).
const Module = require("node:module");
const origResolve = Module._resolveFilename;
Module._resolveFilename = function (request, parent, ...rest) {
  if (request.startsWith(".") && parent?.filename) {
    const base = path.resolve(path.dirname(parent.filename), request);
    for (const ext of [".ts", ".tsx", "/index.ts"]) if (fs.existsSync(base + ext)) return base + ext;
  }
  return origResolve.call(this, request, parent, ...rest);
};
require.extensions[".ts"] = (module, filename) => {
  const out = ts.transpileModule(fs.readFileSync(filename, "utf8"), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020, esModuleInterop: true } });
  module._compile(out.outputText, filename);
};
const load = (f) => require(path.join(root, "src/lib", f));

const errors = [];
const warn = [];
const fail = (m) => errors.push(m);

const { mskConditions } = load("msk-injury-hub.ts");
const { mskConditionIndex } = load("msk-injury-index.ts");
const { mskSpecialTests } = load("msk-special-tests.ts");
const { treatmentPlans } = load("treatment-plans.ts");
const { treatmentPlanGuides } = load("treatment-plan-guides.ts");
const { mskConditionDepth } = load("msk-condition-depth.ts");
const { mskTestEvidence } = load("msk-test-evidence.ts");
const { treatmentPlanEvidence } = load("treatment-plan-evidence.ts");
const { EVIDENCE_REFS } = load("msk-evidence-refs.ts");
load("msk-cross-links.ts"); // throws on any broken link

const dup = (arr, label) => { const s = new Set(); for (const x of arr) { if (s.has(x)) fail("Duplicate " + label + ": " + x); s.add(x); } };
dup(mskConditions.map((c) => c.slug), "condition slug");
dup(treatmentPlans.map((p) => p.slug), "plan slug");
dup(mskSpecialTests.map((t) => t.id), "test id");
dup(mskSpecialTests.map((t) => t.name), "test name");

if (mskConditionIndex.length !== mskConditions.length) fail("Condition index (" + mskConditionIndex.length + ") and hub (" + mskConditions.length + ") differ");
for (const c of mskConditions) {
  if (!mskConditionIndex.some((i) => i.slug === c.slug)) fail("Condition missing from index: " + c.slug);
  if (!mskConditionDepth[c.slug]) fail("Condition without depth entry: " + c.slug);
  for (const f of ["involvedStructures", "mechanism", "symptoms", "signs", "redFlags", "tests", "differentials", "investigations", "treatmentPhases", "manualTherapy", "modalities", "returnCriteria", "commonMistakes", "references"])
    if (!Array.isArray(c[f]) || c[f].length === 0) fail("Condition " + c.slug + " has empty field " + f);
}
for (const p of treatmentPlans) {
  if (!treatmentPlanGuides[p.slug]) fail("Plan without guide: " + p.slug);
}
for (const slug of Object.keys(treatmentPlanGuides)) if (!treatmentPlans.some((p) => p.slug === slug)) fail("Guide without plan: " + slug);

// Reference hygiene
for (const [key, ref] of Object.entries(EVIDENCE_REFS)) {
  if (ref.doi && !/^10\.\d{4,9}\/\S+$/.test(ref.doi)) fail("Malformed DOI in " + key + ": " + ref.doi);
  if (!ref.citation || ref.citation.length < 40) fail("Citation too short: " + key);
  if (!["unverified", "verified"].includes(ref.verification)) fail("Bad verification flag: " + key);
}
const usedKeys = new Set();
for (const d of Object.values(mskConditionDepth)) d.refs.forEach((k) => usedKeys.add(k));
for (const d of Object.values(mskTestEvidence)) d.refs.forEach((k) => usedKeys.add(k));
for (const d of Object.values(treatmentPlanEvidence)) d.refs.forEach((k) => usedKeys.add(k));
for (const k of Object.keys(EVIDENCE_REFS)) if (!usedKeys.has(k)) warn.push("Reference defined but never used: " + k);

// Language safeguards: no absolute claims in evidence layers
const bannedPhrases = [/\bcures?\b/i, /\bguarantee/i, /\balways works\b/i, /\bproven to\b/i, /\bdefinitive(ly)?\b/i];
const scan = (label, text) => { for (const re of bannedPhrases) if (re.test(text)) fail("Absolute wording (" + re + ") in " + label); };
for (const [k, v] of Object.entries(mskTestEvidence)) scan("test evidence " + k, JSON.stringify(v));
for (const [k, v] of Object.entries(mskConditionDepth)) scan("condition depth " + k, JSON.stringify(v));
for (const [k, v] of Object.entries(treatmentPlanEvidence)) scan("plan evidence " + k, JSON.stringify(v));

// Every special test needs a non-trivial procedure and technique guide (also enforced at build time)
for (const t of mskSpecialTests) {
  if (t.steps.length !== 3 || !t.positive || !t.meaning) fail("Incomplete test: " + t.name);
}

const counts = {
  conditions: mskConditions.length,
  conditionsWithDepth: mskConditions.filter((c) => mskConditionDepth[c.slug]).length,
  conditionsLinkedToPlan: mskConditions.filter((c) => mskConditionDepth[c.slug]?.planSlug).length,
  conditionsLinkedToTests: mskConditions.filter((c) => mskConditionDepth[c.slug]?.testIds.length).length,
  plans: treatmentPlans.length,
  plansWithGuide: treatmentPlans.filter((p) => treatmentPlanGuides[p.slug]).length,
  plansWithEvidence: treatmentPlans.filter((p) => treatmentPlanEvidence[p.slug]).length,
  tests: mskSpecialTests.length,
  testsWithEvidence: mskSpecialTests.filter((t) => mskTestEvidence[t.id]).length,
  references: Object.keys(EVIDENCE_REFS).length,
  referencesVerified: Object.values(EVIDENCE_REFS).filter((r) => r.verification === "verified").length,
};
console.log(JSON.stringify(counts, null, 2));
warn.forEach((w) => console.warn("WARN  " + w));
if (errors.length) { errors.forEach((e) => console.error("ERROR " + e)); process.exit(1); }
console.log("MSK content validation passed.");

if (process.argv.includes("--inventory")) {
  const lines = ["# MSK content inventory (generated by scripts/validate-msk-content.mjs)", "", "## Counts", "", "```json", JSON.stringify(counts, null, 2), "```", "", "## Conditions", "", "| Slug | Region | Depth | Plan link | Linked tests | Own tests |", "|---|---|---|---|---|---|"];
  for (const c of mskConditions) { const d = mskConditionDepth[c.slug]; lines.push(`| ${c.slug} | ${c.region} | ${d ? "yes" : "NO"} | ${d?.planSlug ?? "-"} | ${d?.testIds.length ?? 0} | ${c.tests.length} |`); }
  lines.push("", "## Treatment plans", "", "| Slug | Guide | Evidence layer |", "|---|---|---|");
  for (const p of treatmentPlans) lines.push(`| ${p.slug} | ${treatmentPlanGuides[p.slug] ? "yes" : "NO"} | ${treatmentPlanEvidence[p.slug] ? "yes" : "no (non-MSK or not yet upgraded)"} |`);
  lines.push("", "## Special tests", "", "| Id | Region | Evidence layer |", "|---|---|---|");
  for (const t of mskSpecialTests) lines.push(`| ${t.id} | ${t.region} | ${mskTestEvidence[t.id] ? mskTestEvidence[t.id].strength : "no"} |`);
  fs.writeFileSync(path.join(root, "docs/MSK_CONTENT_INVENTORY.md"), lines.join("\n") + "\n");
  console.log("Wrote docs/MSK_CONTENT_INVENTORY.md");
}
