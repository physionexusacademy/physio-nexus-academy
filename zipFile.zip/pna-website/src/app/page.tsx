import Image from "next/image";
import Link from "next/link";
import {
  CalendarDays,
  BookOpen,
  MapPin,
  ArrowRight,
  Quote,
} from "lucide-react";
import { Button } from "@/components/ui/Button";
import { siteConfig } from "@/lib/site-config";
import { createClient } from "@/lib/supabase/server";

export const revalidate = 60;

export default async function HomePage() {
  const supabase = createClient();
  const [
    { data: workshopRows },
    { data: resourceRows },
    { data: testimonialRows },
    { data: founderRow },
    { data: aboutSection },
  ] = await Promise.all([
    supabase
      .from("workshops")
      .select("*")
      .eq("status", "published")
      .order("start_date", { ascending: true, nullsFirst: false })
      .limit(3),
    supabase
      .from("resources")
      .select("*")
      .eq("visibility", "Public")
      .order("created_at", { ascending: false })
      .limit(3),
    supabase
      .from("testimonials")
      .select("*")
      .eq("status", "published")
      .order("sort_order", { ascending: true })
      .limit(3),
    supabase.from("founder_profile").select("*").eq("id", 1).maybeSingle(),
    supabase
      .from("editable_page_sections")
      .select("content")
      .eq("page", "about")
      .eq("section_key", "mission")
      .maybeSingle(),
  ]);

  const about = {
    purpose: aboutSection?.content?.purpose ?? siteConfig.mission.purpose,
    vision: aboutSection?.content?.vision ?? siteConfig.mission.vision,
    mission: aboutSection?.content?.mission ?? siteConfig.mission.mission,
  };

  const founder = {
    name: founderRow?.name || siteConfig.founder.name,
    role: founderRow?.role || siteConfig.founder.role,
    photo: founderRow?.photo_url || siteConfig.founder.photo,
    intro: founderRow?.message_body?.[0] || siteConfig.founder.message.body[0],
  };

  const featuredWorkshops = workshopRows?.length ? workshopRows : null;
  const featuredResources = resourceRows?.length ? resourceRows : null;
  const testimonials = testimonialRows?.length ? testimonialRows : null;

  return (
    <>
      {/* Hero */}
      <section className="relative overflow-hidden bg-navy-800">
        <div className="container-content section-padding grid gap-10 lg:grid-cols-2 lg:items-center">
          <div className="animate-fadeUp text-white">
            <Image
              src="/images/pna-logo.png"
              alt="Physio Nexus Academy logo"
              width={72}
              height={72}
              className="mb-6 h-16 w-16 rounded-md bg-white object-contain p-1.5"
              priority
            />
            <h1 className="text-3xl font-bold leading-tight sm:text-4xl lg:text-5xl">
              Physio Nexus Academy
            </h1>
            <p className="mt-3 text-sm font-semibold uppercase tracking-widest text-teal-300">
              {siteConfig.tagline}
            </p>
            <p className="mt-5 max-w-lg text-base text-grey-200 sm:text-lg">
              Practical physiotherapy education, hands-on workshops and a clear pathway to
              patient care — built for students, professionals and patients alike.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button href="/workshops" size="lg">
                Explore Workshops
              </Button>
              <Button href="/appointment" variant="outline" size="lg" className="border-white text-white hover:bg-white/10">
                Book Appointment
              </Button>
            </div>
            <div className="mt-4 flex flex-wrap gap-3">
              <Button href="/home-visit" variant="secondary" size="md" className="bg-white/10 hover:bg-white/20">
                Request Home Visit
              </Button>
              <Button href="/resources" variant="secondary" size="md" className="bg-white/10 hover:bg-white/20">
                Browse Resources
              </Button>
            </div>
          </div>

          <div className="relative mx-auto w-full max-w-sm animate-fadeUp lg:max-w-md">
            <div className="overflow-hidden rounded-2xl border-4 border-white/10 shadow-2xl">
              <Image
                src={founder.photo}
                alt={`${founder.name}, Founder of Physio Nexus Academy`}
                width={480}
                height={600}
                className="h-full w-full object-cover"
                priority
              />
            </div>
            <div className="absolute -bottom-5 left-1/2 w-[92%] -translate-x-1/2 rounded-xl bg-white p-4 text-center shadow-lg">
              <p className="font-heading text-sm font-semibold text-navy-800">{founder.name}</p>
              <p className="text-xs text-navy-500">{founder.role}</p>
            </div>
          </div>
        </div>
      </section>

      {/* Trust strip */}
      <section className="border-b border-grey-200 bg-grey-50">
        <div className="container-content grid grid-cols-2 gap-4 py-6 sm:grid-cols-4">
          {siteConfig.trustStrip.map((item) => (
            <p
              key={item}
              className="text-center text-xs font-semibold uppercase tracking-wide text-navy-600 sm:text-sm"
            >
              {item}
            </p>
          ))}
        </div>
      </section>

      {/* Featured workshops */}
      <section className="section-padding">
        <div className="container-content">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <h2 className="text-2xl font-bold sm:text-3xl">Featured Workshops</h2>
              <p className="mt-2 max-w-xl text-navy-500">
                Hands-on clinical workshops connecting theory with real practice.
              </p>
            </div>
            <Link href="/workshops" className="flex items-center gap-1 text-sm font-semibold text-teal-600 hover:text-teal-700">
              View all workshops <ArrowRight className="h-4 w-4" />
            </Link>
          </div>

          {featuredWorkshops ? (
            <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {featuredWorkshops.map((w) => (
                <Link
                  key={w.id}
                  href={`/workshops/${w.slug}`}
                  className="rounded-xl border border-grey-200 p-6 transition-shadow hover:shadow-md"
                >
                  <CalendarDays className="h-6 w-6 text-teal-500" />
                  <h3 className="mt-3 font-heading text-lg font-semibold text-navy-800">
                    {w.title}
                  </h3>
                  <p className="mt-2 text-sm text-navy-500">{w.summary}</p>
                  <div className="mt-4 flex items-center gap-2 text-xs text-navy-400">
                    <MapPin className="h-3.5 w-3.5" />
                    {w.city || "City TBA"} •{" "}
                    {w.start_date ? new Date(w.start_date).toLocaleDateString() : "Date TBA"}
                  </div>
                </Link>
              ))}
            </div>
          ) : (
            <p className="mt-8 rounded-xl border border-grey-200 bg-grey-50 p-6 text-center text-navy-400">
              No workshops published yet — check back soon.
            </p>
          )}
        </div>
      </section>

      {/* About snapshot */}
      <section className="section-padding bg-grey-50">
        <div className="container-content grid gap-10 lg:grid-cols-2 lg:items-center">
          <div>
            <h2 className="text-2xl font-bold sm:text-3xl">About Physio Nexus Academy</h2>
            <p className="mt-4 text-navy-600">{about.purpose}</p>
            <Button href="/about" variant="outline" className="mt-6">
              Learn more about PNA
            </Button>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="rounded-xl bg-white p-6 shadow-sm">
              <h3 className="font-heading font-semibold text-navy-800">Our Vision</h3>
              <p className="mt-2 text-sm text-navy-500">{about.vision}</p>
            </div>
            <div className="rounded-xl bg-white p-6 shadow-sm">
              <h3 className="font-heading font-semibold text-navy-800">Our Mission</h3>
              <p className="mt-2 text-sm text-navy-500">{about.mission}</p>
            </div>
          </div>
        </div>
      </section>

      {/* Founder spotlight */}
      <section className="section-padding">
        <div className="container-content grid gap-10 lg:grid-cols-[280px_1fr] lg:items-start">
          <div className="mx-auto w-56 overflow-hidden rounded-xl shadow-lg lg:w-full">
            <Image
              src={founder.photo}
              alt={founder.name}
              width={280}
              height={340}
              className="h-full w-full object-cover"
            />
          </div>
          <div>
            <h2 className="text-2xl font-bold sm:text-3xl">Meet the Founder</h2>
            <p className="mt-1 font-semibold text-teal-600">{founder.name}</p>
            <p className="mt-1 text-sm text-navy-500">{siteConfig.founder.credentialsShort}</p>
            <p className="mt-4 text-navy-600">{founder.intro}</p>
            <Button href="/founder" variant="outline" className="mt-6">
              View full founder profile
            </Button>
          </div>
        </div>
      </section>

      {/* What we offer */}
      <section className="section-padding bg-navy-800 text-white">
        <div className="container-content">
          <h2 className="text-2xl font-bold sm:text-3xl">What We Offer</h2>
          <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {siteConfig.whatWeOffer.map((item) => (
              <Link
                key={item.title}
                href={item.href}
                className="rounded-xl border border-white/10 p-6 transition-colors hover:border-teal-400 hover:bg-white/5"
              >
                <h3 className="font-heading font-semibold">{item.title}</h3>
                <p className="mt-2 text-sm text-grey-200">{item.description}</p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Featured resources */}
      <section className="section-padding">
        <div className="container-content">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <h2 className="text-2xl font-bold sm:text-3xl">Featured Books &amp; Resources</h2>
            <Link href="/resources" className="flex items-center gap-1 text-sm font-semibold text-teal-600 hover:text-teal-700">
              Browse library <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
          {featuredResources ? (
            <div className="mt-8 grid gap-5 sm:grid-cols-3">
              {featuredResources.map((r) => (
                <div key={r.id} className="flex items-start gap-3 rounded-xl border border-grey-200 p-5">
                  <BookOpen className="h-6 w-6 flex-shrink-0 text-teal-500" />
                  <div>
                    <p className="font-medium text-navy-800">{r.title}</p>
                    <p className="text-xs uppercase tracking-wide text-navy-400">{r.access_type}</p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="mt-8 rounded-xl border border-grey-200 bg-grey-50 p-6 text-center text-navy-400">
              No public resources yet — check back soon.
            </p>
          )}
        </div>
      </section>

      {/* Testimonials */}
      <section className="section-padding bg-grey-50">
        <div className="container-content">
          <h2 className="text-center text-2xl font-bold sm:text-3xl">What People Say</h2>
          {testimonials ? (
            <div className="mt-8 grid gap-6 sm:grid-cols-3">
              {testimonials.map((t) => (
                <div key={t.id} className="rounded-xl bg-white p-6 shadow-sm">
                  <Quote className="h-6 w-6 text-teal-300" />
                  <p className="mt-3 text-sm italic text-navy-500">{t.content}</p>
                  <p className="mt-4 text-sm font-semibold text-navy-700">
                    — {t.name}{t.role ? `, ${t.role}` : ""}
                  </p>
                </div>
              ))}
            </div>
          ) : (
            <p className="mt-8 text-center text-navy-400">
              Testimonials will appear here once added from the Admin Dashboard.
            </p>
          )}
        </div>
      </section>

      {/* Final CTA */}
      <section className="section-padding bg-teal-500">
        <div className="container-content flex flex-col items-center gap-6 text-center text-white">
          <h2 className="max-w-2xl text-2xl font-bold sm:text-3xl">
            Ready to learn, apply and grow with Physio Nexus Academy?
          </h2>
          <div className="flex flex-wrap justify-center gap-3">
            <Button href="/workshops" variant="secondary" size="lg" className="bg-white text-teal-700 hover:bg-grey-100">
              Explore Workshops
            </Button>
            <Button href="/contact" variant="outline" size="lg" className="border-white text-white hover:bg-white/10">
              Get in Touch
            </Button>
          </div>
        </div>
      </section>
    </>
  );
}
